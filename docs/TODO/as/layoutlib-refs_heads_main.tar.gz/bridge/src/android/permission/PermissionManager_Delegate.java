/*
 * Copyright (C) 2022 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package android.permission;

import com.android.tools.layoutlib.annotations.LayoutlibDelegate;

import android.content.pm.PackageManager;

public class PermissionManager_Delegate {

    @LayoutlibDelegate
    public static int checkPermission(String permission, int pid, int uid, int deviceId) {
        return PackageManager.PERMISSION_GRANTED;
    }

    @LayoutlibDelegate
    public static int checkPermission(PermissionManager thisManager, String permissionName,
            String packageName, String persistentDeviceId) {
        return PackageManager.PERMISSION_GRANTED;
    }
}
