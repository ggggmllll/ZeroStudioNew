/*
 * Copyright (C) 2023 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.android.tools.layoutlib.create;

import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.FieldVisitor;

import java.util.Set;

import static org.objectweb.asm.Opcodes.ACC_FINAL;

/**
 * Removes the final modifier from the given fields.
 */
public class RemoveFinalModifierFieldClassAdapter extends ClassVisitor {

    private final Set<String> mFieldNames;

    public RemoveFinalModifierFieldClassAdapter(ClassVisitor cv, Set<String> fieldNames) {
        super(Main.ASM_VERSION, cv);
        mFieldNames = fieldNames;
    }

    @Override
    public FieldVisitor visitField(int access, String name, String desc, String signature,
            Object value) {
        if (mFieldNames.contains(name)) {
            access = access & ~ACC_FINAL;
        }
        return super.visitField(access, name, desc, signature, value);
    }
}
