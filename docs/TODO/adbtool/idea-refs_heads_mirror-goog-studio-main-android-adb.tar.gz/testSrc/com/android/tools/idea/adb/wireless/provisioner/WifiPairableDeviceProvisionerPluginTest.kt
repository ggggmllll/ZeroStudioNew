/*
 * Copyright (C) 2025 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.android.tools.idea.adb.wireless.provisioner

import com.android.adblib.AdbFeatures
import com.android.adblib.AdbSession
import com.android.adblib.ConnectedDevice
import com.android.adblib.CoroutineScopeCache
import com.android.adblib.DeviceInfo
import com.android.adblib.MdnsServices
import com.android.adblib.MdnsTlsService
import com.android.adblib.MdnsTrackServiceInfo
import com.android.adblib.ServerStatus
import com.android.adblib.ServiceInstanceName
import com.android.tools.idea.adb.AdbServerStatusRetriever
import com.android.tools.idea.adb.wireless.AdbCommandResult
import com.android.tools.idea.adb.wireless.AdbOnlineDevice
import com.android.tools.idea.adb.wireless.AdbServiceWrapper
import com.android.tools.idea.adb.wireless.MockWiFiPairingNotificationService
import com.android.tools.idea.adb.wireless.PairDevicesUsingWiFiService
import com.android.tools.idea.adb.wireless.PairingResult
import com.android.tools.idea.adb.wireless.TrackingMdnsService
import com.android.tools.idea.adb.wireless.WiFiPairingController
import com.android.tools.idea.adb.wireless.v2.ui.WifiPairableDevicesPersistentStateComponent
import com.android.tools.idea.concurrency.pumpEventsAndWaitForFuture
import com.android.tools.idea.testing.ApplicationServiceRule
import com.android.tools.idea.testing.ProjectServiceRule
import com.google.common.truth.Truth.assertThat
import com.intellij.notification.NotificationType
import com.intellij.openapi.project.Project
import com.intellij.testFramework.ApplicationRule
import com.intellij.testFramework.EdtRule
import com.intellij.testFramework.ProjectRule
import com.intellij.testFramework.RuleChain
import com.intellij.testFramework.RunsInEdt
import com.intellij.testFramework.common.waitUntil
import icons.StudioIcons
import java.io.IOException
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.isActive
import kotlinx.coroutines.test.advanceTimeBy
import kotlinx.coroutines.test.runTest
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.mockito.kotlin.any
import org.mockito.kotlin.argThat
import org.mockito.kotlin.doReturn
import org.mockito.kotlin.mock
import org.mockito.kotlin.verify
import org.mockito.kotlin.whenever

@RunsInEdt
@ExperimentalCoroutinesApi
class WifiPairableDeviceProvisionerPluginTest {

  private val adbService = FakeAdbServiceWrapper()
  private lateinit var pairingController: WiFiPairingController
  private val pairDevicesService = mock<PairDevicesUsingWiFiService>()
  private lateinit var notificationService: MockWiFiPairingNotificationService
  private val mockPersistentService = mock<WifiPairableDevicesPersistentStateComponent>()
  private val mockAdbServerStatusRetriever = mock<AdbServerStatusRetriever>()
  private val serverStatusFlow = MutableStateFlow<ServerStatus?>(ServerStatus(version = "37.0.0"))

  private val projectRule = ProjectRule()
  val project: Project
    get() = projectRule.project

  @get:Rule
  val rule =
    RuleChain(
      EdtRule(),
      ApplicationRule(),
      projectRule,
      ApplicationServiceRule(WifiPairableDevicesPersistentStateComponent::class.java, mockPersistentService),
      ProjectServiceRule(projectRule, PairDevicesUsingWiFiService::class.java, pairDevicesService),
      ProjectServiceRule(projectRule, AdbServerStatusRetriever::class.java, mockAdbServerStatusRetriever),
    )

  private val mdnsFlow = MutableStateFlow(MdnsServices(emptyList(), emptyList(), emptyList()))

  private val WifiPairableDeviceProvisionerPlugin.WifiPairableDeviceHandle.mdnsService: MdnsTrackServiceInfo
    get() = (this.state.properties as WifiPairableDeviceProvisionerPlugin.WifiPairableDeviceProperties).mdnsService

  @Before
  fun setUp() {
    pairingController = mock()
    notificationService = MockWiFiPairingNotificationService(project)
    whenever(pairDevicesService.createPairingDialogController(any())).thenReturn(pairingController)
    adbService.setMdnsTrackServicesFlow(mdnsFlow)
    adbService.setHostFeatures(listOf(AdbFeatures.TRACK_MDNS_SERVICE))
    doReturn(MutableStateFlow(emptySet<String>())).whenever(mockPersistentService).hiddenDevices
    whenever(mockAdbServerStatusRetriever.serverStatus).thenReturn(serverStatusFlow)
  }

  @Test
  fun pluginDoesNothing_whenMdnsTrackingNotSupported() = runTest {
    adbService.setHostFeatures(emptyList())
    mdnsFlow.value = createMdnsTlsService("service1")
    val plugin = WifiPairableDeviceProvisionerPlugin(backgroundScope, adbService, project, notificationService)
    advanceTimeBy(6000) // Past initial delay

    assertThat(plugin.devices.value).isEmpty()
  }

  @Test
  fun pluginDoesNothing_whenAdbVersionTooLow() = runTest {
    serverStatusFlow.value = ServerStatus(version = "36.0.0")
    mdnsFlow.value = createMdnsTlsService("service1")
    val plugin = WifiPairableDeviceProvisionerPlugin(backgroundScope, adbService, project, notificationService)
    advanceTimeBy(6000) // Past initial delay

    assertThat(plugin.devices.value).isEmpty()
  }

  @Test
  fun pluginStartsTracking_whenAdbIsUpdated() = runTest {
    serverStatusFlow.value = ServerStatus(version = "36.0.0")
    mdnsFlow.value = createMdnsTlsService("service1")
    val plugin = WifiPairableDeviceProvisionerPlugin(backgroundScope, adbService, project, notificationService)
    advanceTimeBy(6000) // Past initial delay

    assertThat(plugin.devices.value).isEmpty()

    serverStatusFlow.value = ServerStatus(version = "37.0.0")
    advanceTimeBy(1000) // Past loop delay

    assertThat(plugin.devices.value).hasSize(1)
  }

  @Test
  fun newMdnsService_createsDeviceHandle() = runTest {
    mdnsFlow.value = createMdnsTlsService("service1")
    val plugin = WifiPairableDeviceProvisionerPlugin(backgroundScope, adbService, project, notificationService)
    advanceTimeBy(6000) // Past initial delay

    assertThat(plugin.devices.value).hasSize(1)
    val handle = plugin.devices.value.first() as WifiPairableDeviceProvisionerPlugin.WifiPairableDeviceHandle
    assertThat(handle.mdnsService.serviceInstanceName.instance).isEqualTo("service1")
    assertThat(handle.state.properties.model).isEqualTo("Pixel 8 at 192.168.1.100:4321")
    assertThat(handle.state.error).isNull()
  }

  @Test
  fun newMdnsService_emulatorService_filtersOut() = runTest {
    mdnsFlow.value = createMdnsTlsService("adb-EMULATOR2342-ABCDE")
    val plugin = WifiPairableDeviceProvisionerPlugin(backgroundScope, adbService, project, notificationService)
    advanceTimeBy(6000) // Past initial delay

    assertThat(plugin.devices.value).isEmpty()
  }

  @Test
  fun newMdnsService_withGivenName() = runTest {
    mdnsFlow.value = createMdnsTlsService("service1", givenName = "Foo Pixel")
    val plugin = WifiPairableDeviceProvisionerPlugin(backgroundScope, adbService, project, notificationService)
    advanceTimeBy(6000) // Past initial delay

    assertThat(plugin.devices.value).hasSize(1)
    val handle = plugin.devices.value.first() as WifiPairableDeviceProvisionerPlugin.WifiPairableDeviceHandle
    assertThat(handle.mdnsService.serviceInstanceName.instance).isEqualTo("service1")
    assertThat(handle.state.properties.model).isEqualTo("Foo Pixel")
    assertThat(handle.state.error).isNull()
  }

  @Test
  fun newMdnsService_userChangesDeviceName_reusesSameHandle_nameGetsUpdated() = runTest {
    mdnsFlow.value = createMdnsTlsService("service1", givenName = "Foo Pixel")
    val plugin = WifiPairableDeviceProvisionerPlugin(backgroundScope, adbService, project, notificationService)
    advanceTimeBy(6000) // Past initial delay

    assertThat(plugin.devices.value).hasSize(1)
    val handle = plugin.devices.value.first() as WifiPairableDeviceProvisionerPlugin.WifiPairableDeviceHandle
    assertThat(handle.mdnsService.serviceInstanceName.instance).isEqualTo("service1")
    assertThat(handle.state.properties.model).isEqualTo("Foo Pixel")
    assertThat(handle.state.error).isNull()

    mdnsFlow.value = createMdnsTlsService("service1", givenName = "New Foo Pixel")

    assertThat(plugin.devices.value).hasSize(1)
    waitUntil {
      handle.state.properties.model == "New Foo Pixel" &&
        handle.mdnsService.serviceInstanceName.instance == "service1" &&
        handle.state.error == null
    }

    handle.wifiPairDeviceAction!!.pair()

    verify(pairDevicesService)
      .createPairingDialogController(argThat { s: TrackingMdnsService -> s.serviceName == "service1" && s.deviceName == "New Foo Pixel" })
    verify(pairingController).showDialog()
  }

  @Test
  fun newMdnsService_withModel() = runTest {
    mdnsFlow.value = createMdnsTlsService("service1", model = "Pixel")
    val plugin = WifiPairableDeviceProvisionerPlugin(backgroundScope, adbService, project, notificationService)
    advanceTimeBy(6000) // Past initial delay

    assertThat(plugin.devices.value).hasSize(1)
    val handle = plugin.devices.value.first() as WifiPairableDeviceProvisionerPlugin.WifiPairableDeviceHandle
    assertThat(handle.mdnsService.serviceInstanceName.instance).isEqualTo("service1")
    assertThat(handle.state.properties.model).isEqualTo("Pixel at 192.168.1.100:4321")
    assertThat(handle.state.error).isNull()
  }

  @Test
  fun newMdnsService_withNullModelAndNullGivenName_createsDeviceHandleWithFallbackName() = runTest {
    mdnsFlow.value = createMdnsTlsService("service1", model = null)
    val plugin = WifiPairableDeviceProvisionerPlugin(backgroundScope, adbService, project, notificationService)
    advanceTimeBy(6000) // Past initial delay

    assertThat(plugin.devices.value).hasSize(1)
    val handle = plugin.devices.value.first() as WifiPairableDeviceProvisionerPlugin.WifiPairableDeviceHandle
    assertThat(handle.mdnsService.serviceInstanceName.instance).isEqualTo("service1")
    assertThat(handle.state.properties.model).isEqualTo("Device at 192.168.1.100:4321")
    assertThat(handle.state.error).isNull()
  }

  @Test
  fun newMdnsService_oldMdnsVersion_displayWarning() = runTest {
    mdnsFlow.value = createMdnsTlsService("service1", mdnsServiceVersion = "1")
    val plugin = WifiPairableDeviceProvisionerPlugin(backgroundScope, adbService, project, notificationService)
    advanceTimeBy(6000) // Past initial delay

    assertThat(plugin.devices.value).hasSize(1)
    val handle = plugin.devices.value.first() as WifiPairableDeviceProvisionerPlugin.WifiPairableDeviceHandle
    assertThat(handle.mdnsService.serviceInstanceName.instance).isEqualTo("service1")
    assertThat(handle.state.error!!.message).isEqualTo("Check for device software updates to improve Wi-Fi pairing.")
  }

  @Test
  fun knownDevices_areIgnored() = runTest {
    mdnsFlow.value = createMdnsTlsService("adb-35121FDJH000R8-fYN6pK")
    val plugin = WifiPairableDeviceProvisionerPlugin(backgroundScope, adbService, project, notificationService)
    val cache: CoroutineScopeCache = mock()
    whenever(cache.scope).thenReturn(backgroundScope)
    plugin.claim(
      object : ConnectedDevice {
        override val session: AdbSession
          get() = TODO("Not yet implemented")

        override val cache: CoroutineScopeCache
          get() = cache

        override val deviceInfoFlow: StateFlow<DeviceInfo>
          get() = _deviceInfoFlow

        private val _deviceInfoFlow: MutableStateFlow<DeviceInfo> =
          MutableStateFlow(DeviceInfo("adb-35121FDJH000R8-fYN6pK._adb-tls-connect._tcp", mock()))
      }
    )
    advanceTimeBy(6000) // Past initial delay

    assertThat(plugin.devices.value).isEmpty()
  }

  @Test
  fun hiddenDevices_areIgnored() = runTest {
    doReturn(MutableStateFlow(setOf("service1"))).whenever(mockPersistentService).hiddenDevices
    mdnsFlow.value = createMdnsTlsService("service1")
    val plugin = WifiPairableDeviceProvisionerPlugin(backgroundScope, adbService, project, notificationService)
    advanceTimeBy(6000) // Past initial delay

    assertThat(plugin.devices.value).isEmpty()
  }

  @Test
  fun pairAction_entryWithModel_launchesPairingDialogWithCorrectName() = runTest {
    mdnsFlow.value = createMdnsTlsService("service1", "Pixel", "1.2.3.4", 1234)
    val plugin = WifiPairableDeviceProvisionerPlugin(backgroundScope, adbService, project, notificationService)
    advanceTimeBy(6000) // Past initial delay

    val handle = plugin.devices.value.first()
    handle.wifiPairDeviceAction!!.pair()

    verify(pairDevicesService)
      .createPairingDialogController(
        argThat { s: TrackingMdnsService ->
          s.serviceName == "service1" && s.deviceName == "Pixel" && s.ipv4 == "1.2.3.4" && s.port == "1234" && s.mdnsServiceVersion == "2.0"
        }
      )
    verify(pairingController).showDialog()
  }

  @Test
  fun pairAction_entryWithGivenName_launchesPairingDialogWithCorrectName() = runTest {
    mdnsFlow.value = createMdnsTlsService("service1", "Pixel", "1.2.3.4", 1234, givenName = "Foo Pixel")
    val plugin = WifiPairableDeviceProvisionerPlugin(backgroundScope, adbService, project, notificationService)
    advanceTimeBy(6000) // Past initial delay

    val handle = plugin.devices.value.first()
    handle.wifiPairDeviceAction!!.pair()

    verify(pairDevicesService)
      .createPairingDialogController(
        argThat { s: TrackingMdnsService ->
          s.serviceName == "service1" &&
            s.deviceName == "Foo Pixel" &&
            s.ipv4 == "1.2.3.4" &&
            s.port == "1234" &&
            s.mdnsServiceVersion == "2.0"
        }
      )
    verify(pairingController).showDialog()
  }

  @Test
  fun pairAction_entryWithNoName_launchesPairingDialogWithCorrectName() = runTest {
    mdnsFlow.value = createMdnsTlsService("service1", null, "1.2.3.4", 1234, givenName = null)
    val plugin = WifiPairableDeviceProvisionerPlugin(backgroundScope, adbService, project, notificationService)
    advanceTimeBy(6000) // Past initial delay

    val handle = plugin.devices.value.first()
    handle.wifiPairDeviceAction!!.pair()

    verify(pairDevicesService)
      .createPairingDialogController(
        argThat { s: TrackingMdnsService ->
          s.serviceName == "service1" &&
            s.deviceName == "Device" &&
            s.ipv4 == "1.2.3.4" &&
            s.port == "1234" &&
            s.mdnsServiceVersion == "2.0"
        }
      )
    verify(pairingController).showDialog()
  }

  @Test
  fun pairAction_entryWithOldMdnsVersion_launchesPairingDialogWithCorrectVersion() = runTest {
    mdnsFlow.value = createMdnsTlsService("service1", null, "1.2.3.4", 1234, mdnsServiceVersion = "1")
    val plugin = WifiPairableDeviceProvisionerPlugin(backgroundScope, adbService, project, notificationService)
    advanceTimeBy(6000) // Past initial delay

    val handle = plugin.devices.value.first()
    handle.wifiPairDeviceAction!!.pair()

    verify(pairDevicesService)
      .createPairingDialogController(
        argThat { s: TrackingMdnsService ->
          s.serviceName == "service1" && s.deviceName == "Device" && s.ipv4 == "1.2.3.4" && s.port == "1234" && s.mdnsServiceVersion == "1"
        }
      )
    verify(pairingController).showDialog()
  }

  @Test
  fun hideAction_addsDeviceToHiddenList() = runTest {
    mdnsFlow.value = createMdnsTlsService("service1", "My Pixel", "1.2.3.4", 1234)
    val plugin = WifiPairableDeviceProvisionerPlugin(backgroundScope, adbService, project, notificationService)
    advanceTimeBy(6000) // Past initial delay

    val handle = plugin.devices.value.first()
    handle.hideDeviceAction!!.hide()

    verify(mockPersistentService).addHiddenDevice("service1")

    val (title, content, type, icon) = pumpEventsAndWaitForFuture(notificationService.showBalloonTracker.consume(), 5, TimeUnit.SECONDS)
    assertThat(title).isEqualTo("My Pixel is now hidden")
    assertThat(content).isEqualTo("You can view and pair all devices by using the Wi-Fi pairing dialog.")
    assertThat(type).isEqualTo(NotificationType.INFORMATION)
    assertThat(icon).isEqualTo(StudioIcons.Common.SUCCESS)
  }

  @Test
  fun handleScopeIsCancelled_onRemoval() = runTest {
    mdnsFlow.value = createMdnsTlsService("service1", "My Pixel", "1.2.3.4", 1234)
    val plugin = WifiPairableDeviceProvisionerPlugin(backgroundScope, adbService, project, notificationService)
    advanceTimeBy(6000) // Past initial delay

    val handle = plugin.devices.value.first()
    assertThat(handle.scope.isActive).isTrue()

    mdnsFlow.value = MdnsServices(emptyList(), emptyList(), emptyList())
    waitUntil { !handle.scope.isActive }
    assertThat(plugin.devices.value).isEmpty()
  }

  @Test
  fun mdnsTracking_retriesWithExponentialBackoff() = runTest {
    var attempt = 0
    val failingFlow = flow {
      attempt++
      if (attempt <= 2) {
        throw IOException("ADB connection failed")
      } else {
        emit(createMdnsTlsService("service1"))
      }
    }
    adbService.setMdnsTrackServicesFlow(failingFlow)
    val plugin = WifiPairableDeviceProvisionerPlugin(backgroundScope, adbService, project, notificationService)

    assertThat(plugin.devices.value).isEmpty()

    // First retry delay: 1000ms
    advanceTimeBy(1001)
    assertThat(plugin.devices.value).isEmpty()

    // Second retry delay: 2000ms
    advanceTimeBy(2001)

    assertThat(plugin.devices.value).hasSize(1)
    assertThat(attempt).isEqualTo(3)
  }

  @Test
  fun mdnsTracking_doesNotRetryOnCancellation() = runTest {
    var attempts = 0
    val flow =
      flow<MdnsServices> {
        attempts++
        throw CancellationException()
      }
    adbService.setMdnsTrackServicesFlow(flow)
    val plugin = WifiPairableDeviceProvisionerPlugin(backgroundScope, adbService, project, notificationService)
    advanceTimeBy(6000) // Past initial delay

    assertThat(attempts).isEqualTo(1)
    assertThat(plugin.devices.value).isEmpty()
  }

  private class FakeAdbServiceWrapper : AdbServiceWrapper {
    private var hostFeatures = emptyList<String>()
    private var mdnsFlow: Flow<MdnsServices> = flowOf()

    fun setHostFeatures(features: List<String>) {
      hostFeatures = features
    }

    fun setMdnsTrackServicesFlow(flow: Flow<MdnsServices>) {
      mdnsFlow = flow
    }

    override suspend fun getHostFeatures(): List<String> = hostFeatures

    override fun trackMdnsServices(): Flow<MdnsServices> = mdnsFlow

    override suspend fun executeCommand(args: List<String>, stdin: String): AdbCommandResult {
      TODO("Not implemented")
    }

    override suspend fun waitForOnlineDevice(pairingResult: PairingResult): AdbOnlineDevice {
      TODO("Not implemented")
    }

    override suspend fun getServerStatus(): ServerStatus {
      TODO("Not implemented")
    }
  }

  private fun createMdnsTlsService(
    instanceName: String,
    model: String? = "Pixel 8",
    ipv4: String = "192.168.1.100",
    port: Int = 4321,
    knownDevice: Boolean = false,
    sdk: String = "34",
    givenName: String? = null,
    serial: String? = null,
    mdnsServiceVersion: String? = "2.0",
  ): MdnsServices {
    val serviceInfo =
      MdnsTrackServiceInfo(
        serviceInstanceName = ServiceInstanceName(instanceName, "_adb-tls-connect._tcp", "local"),
        deviceModel = model,
        ipv4 = ipv4,
        port = port,
        ipv6 = emptyList(),
        buildVersionSdkFull = sdk,
        givenName = givenName,
        serial = serial,
        mdnsServiceVersion = mdnsServiceVersion,
      )
    val services = listOf(MdnsTlsService(serviceInfo, knownDevice))
    return MdnsServices(emptyList(), services, emptyList())
  }
}
