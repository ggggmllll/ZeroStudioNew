/*
 * Copyright (C) 2025 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.android.tools.idea.adb.wireless.v2.ui

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.hasTestTag
import androidx.compose.ui.test.isEditable
import androidx.compose.ui.test.onNodeWithContentDescription
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performTextInput
import com.android.adblib.MdnsServices
import com.android.adblib.MdnsTlsService
import com.android.adblib.MdnsTrackServiceInfo
import com.android.adblib.ServiceInstanceName
import com.android.tools.adtui.compose.utils.StudioComposeTestRule.Companion.createStudioComposeTestRule
import com.android.tools.adtui.compose.utils.lingerMouseHover
import com.android.tools.idea.adb.wireless.MdnsSupportState
import com.android.tools.idea.adb.wireless.PairDevicesUsingWiFiService
import com.android.tools.idea.adb.wireless.TrackingMdnsService
import com.android.tools.idea.adb.wireless.WiFiPairingController
import com.android.tools.idea.adb.wireless.WiFiPairingService
import com.android.tools.idea.adb.wireless.v2.ui.WifiAvailableDevicesDialog.Companion.SEARCH_BAR_TEST_TAG
import com.android.tools.idea.adb.wireless.v2.ui.WifiAvailableDevicesDialog.Companion.WARNING_TOOLTIP_TEST_TAG
import com.android.tools.idea.testing.ProjectServiceRule
import com.intellij.testFramework.ApplicationRule
import com.intellij.testFramework.DisposableRule
import com.intellij.testFramework.EdtRule
import com.intellij.testFramework.ProjectRule
import com.intellij.testFramework.RuleChain
import com.intellij.testFramework.RunsInEdt
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.mockito.Mockito.mock
import org.mockito.kotlin.any
import org.mockito.kotlin.argThat
import org.mockito.kotlin.verify
import org.mockito.kotlin.whenever

@RunsInEdt
class WifiAvailableDevicesDialogTest {
  private val mockWiFiPairingService = mock<WiFiPairingService>()
  private val mockPairDevicesUsingWiFiService = mock<PairDevicesUsingWiFiService>()
  private lateinit var mockPairingDialogController: WiFiPairingController

  private val adblibMdnsServicesFlow = MutableStateFlow(MdnsServices(emptyList(), emptyList(), emptyList()))

  private lateinit var wifiAvailableDevicesDialog: WifiAvailableDevicesDialog

  private val composeTestRule = createStudioComposeTestRule()
  private val projectRule = ProjectRule()
  private val disposableRule = DisposableRule()

  @get:Rule
  val rule =
    RuleChain(
      EdtRule(),
      ApplicationRule(),
      disposableRule,
      projectRule,
      ProjectServiceRule(projectRule, PairDevicesUsingWiFiService::class.java, mockPairDevicesUsingWiFiService),
      composeTestRule,
    )

  @Before
  fun setUp() {
    mockPairingDialogController = mock()
    wifiAvailableDevicesDialog = WifiAvailableDevicesDialog(projectRule.project, mockWiFiPairingService)
    whenever(mockPairDevicesUsingWiFiService.createPairingDialogController(any())).thenReturn(mockPairingDialogController)
    whenever(mockWiFiPairingService.trackMdnsServices()).thenReturn(adblibMdnsServicesFlow)
    runBlocking { whenever(mockWiFiPairingService.getAdbVersion()).thenReturn("37.0.0") }
  }

  @After
  fun tearDown() {
    // Need to call dialog.close for it to clean itself up and not leak references.
    wifiAvailableDevicesDialog.closeDialog()
  }

  private fun createMdnsTlsService(
    instance: String,
    ipv4: String,
    port: Int,
    model: String? = "Pixel Test",
    sdk: String? = "33",
    knownDevice: Boolean = false,
    givenName: String? = null,
    serial: String? = null,
    mdnsServiceVersion: String? = null,
  ): MdnsTlsService {
    return MdnsTlsService(
      MdnsTrackServiceInfo(
        ServiceInstanceName(instance, "_adb-tls-connect._tcp", "local"),
        ipv4,
        emptyList(),
        port,
        model,
        sdk,
        givenName,
        serial,
        mdnsServiceVersion,
      ),
      knownDevice,
    )
  }

  @Test
  fun initialState_showsLoading() = runTest {
    whenever(mockWiFiPairingService.checkMdnsSupport()).thenReturn(null) // Simulate loading
    composeTestRule.setContent { wifiAvailableDevicesDialog.WifiDialog() }

    composeTestRule.onNodeWithText("Preparing Wi-Fi pairing...").assertIsDisplayed()
  }

  @Test
  fun mdnsNotSupported_showsNotSupportedError() = runTest {
    whenever(mockWiFiPairingService.checkMdnsSupport()).thenReturn(MdnsSupportState.NotSupported)
    composeTestRule.setContent { wifiAvailableDevicesDialog.WifiDialog() }

    composeTestRule.onNodeWithText("Wi-Fi Pairing Not Supported", substring = true).assertIsDisplayed()
    composeTestRule.onNodeWithText("Open SDK Manager", substring = true).assertIsDisplayed()
  }

  @Test
  fun mdnsSupported_mdnsTrackingNotAvailable_showsAdbVersionTooLowError() = runTest {
    whenever(mockWiFiPairingService.checkMdnsSupport()).thenReturn(MdnsSupportState.Supported)
    whenever(mockWiFiPairingService.isTrackMdnsServiceAvailable()).thenReturn(false)
    composeTestRule.setContent { wifiAvailableDevicesDialog.WifiDialog() }

    composeTestRule.onNodeWithText("ADB Version Too Low", substring = true).assertIsDisplayed()
    composeTestRule.onNodeWithText("Open SDK Manager", substring = true).assertIsDisplayed()
    composeTestRule.onNodeWithText("Learn more", substring = true).assertIsDisplayed()
  }

  @Test
  fun mdnsSupported_adbVersionBelow37_showsAdbVersionTooLowError() = runTest {
    whenever(mockWiFiPairingService.checkMdnsSupport()).thenReturn(MdnsSupportState.Supported)
    whenever(mockWiFiPairingService.isTrackMdnsServiceAvailable()).thenReturn(true)
    whenever(mockWiFiPairingService.getAdbVersion()).thenReturn("36.0.0")

    composeTestRule.setContent { wifiAvailableDevicesDialog.WifiDialog() }

    composeTestRule.onNodeWithText("ADB Version Too Low", substring = true).assertIsDisplayed()
    composeTestRule.onNodeWithText("Open SDK Manager", substring = true).assertIsDisplayed()
    composeTestRule.onNodeWithText("Learn more", substring = true).assertIsDisplayed()
  }

  @Test
  fun mdnsSupported_adbVersion37_showsDevices() = runTest {
    whenever(mockWiFiPairingService.checkMdnsSupport()).thenReturn(MdnsSupportState.Supported)
    whenever(mockWiFiPairingService.isTrackMdnsServiceAvailable()).thenReturn(true)
    whenever(mockWiFiPairingService.getAdbVersion()).thenReturn("37.0.0")

    val service = createMdnsTlsService("service1", "192.168.1.101", 5555, "Device A", "30")
    adblibMdnsServicesFlow.value = MdnsServices(emptyList(), listOf(service), emptyList())

    composeTestRule.setContent { wifiAvailableDevicesDialog.WifiDialog() }

    composeTestRule.onNodeWithText("Device A").assertIsDisplayed()
    composeTestRule.onNodeWithText("192.168.1.101:5555").assertIsDisplayed()
  }

  @Test
  fun mdnsSupported_adbVersion3703_showsDevices() = runTest {
    whenever(mockWiFiPairingService.checkMdnsSupport()).thenReturn(MdnsSupportState.Supported)
    whenever(mockWiFiPairingService.isTrackMdnsServiceAvailable()).thenReturn(true)
    whenever(mockWiFiPairingService.getAdbVersion()).thenReturn("37.0.3")

    val service = createMdnsTlsService("service1", "192.168.1.101", 5555, "Device A", "30")
    adblibMdnsServicesFlow.value = MdnsServices(emptyList(), listOf(service), emptyList())

    composeTestRule.setContent { wifiAvailableDevicesDialog.WifiDialog() }

    composeTestRule.onNodeWithText("Device A").assertIsDisplayed()
    composeTestRule.onNodeWithText("192.168.1.101:5555").assertIsDisplayed()
  }

  @Test
  fun adbVersionTooLow_showsAdbVersionTooLowError() = runTest {
    whenever(mockWiFiPairingService.checkMdnsSupport()).thenReturn(MdnsSupportState.AdbVersionTooLow)
    composeTestRule.setContent { wifiAvailableDevicesDialog.WifiDialog() }

    composeTestRule.onNodeWithText("ADB Version Too Low", substring = true).assertIsDisplayed()
    composeTestRule.onNodeWithText("Open SDK Manager", substring = true).assertIsDisplayed()
    composeTestRule.onNodeWithText("Learn more", substring = true).assertIsDisplayed()
  }

  @Test
  fun adbInvocationError_showsAdbInvocationError() = runTest {
    whenever(mockWiFiPairingService.checkMdnsSupport()).thenReturn(MdnsSupportState.AdbInvocationError)
    composeTestRule.setContent { wifiAvailableDevicesDialog.WifiDialog() }

    composeTestRule.onNodeWithText("ADB Invocation Error", substring = true).assertIsDisplayed()
    composeTestRule.onNodeWithText("Learn more", substring = true).assertIsDisplayed()
  }

  @Test
  fun adbDisabled_showsMdnsDisabledError() = runTest {
    whenever(mockWiFiPairingService.checkMdnsSupport()).thenReturn(MdnsSupportState.AdbDisabled)
    composeTestRule.setContent { wifiAvailableDevicesDialog.WifiDialog() }

    composeTestRule.onNodeWithText("mDNS Disabled in ADB", substring = true).assertIsDisplayed()
    composeTestRule.onNodeWithText("Open ADB Settings", substring = true).assertIsDisplayed()
    composeTestRule.onNodeWithText("Learn more", substring = true).assertIsDisplayed()
  }

  @Test
  fun mdnsSupported_noDevices_showsEmptyState() = runTest {
    whenever(mockWiFiPairingService.isTrackMdnsServiceAvailable()).thenReturn(true)
    whenever(mockWiFiPairingService.checkMdnsSupport()).thenReturn(MdnsSupportState.Supported)
    composeTestRule.setContent { wifiAvailableDevicesDialog.WifiDialog() }

    composeTestRule.onNodeWithText("No devices found.", substring = true).assertIsDisplayed()
  }

  @Test
  fun mdnsSupported_withDevices_showsTable() = runTest {
    whenever(mockWiFiPairingService.isTrackMdnsServiceAvailable()).thenReturn(true)
    whenever(mockWiFiPairingService.checkMdnsSupport()).thenReturn(MdnsSupportState.Supported)
    val service = createMdnsTlsService("service1", "192.168.1.101", 5555, "Device A", "30")
    adblibMdnsServicesFlow.value = MdnsServices(emptyList(), listOf(service), emptyList())
    composeTestRule.setContent { wifiAvailableDevicesDialog.WifiDialog() }

    composeTestRule.onNodeWithText("Device A").assertIsDisplayed()
    composeTestRule.onNodeWithText("192.168.1.101:5555").assertIsDisplayed()
    composeTestRule.onNodeWithText("30").assertIsDisplayed()
  }

  @Test
  fun mdnsSupported_withDevices_usesCorrectDeviceNames() = runTest {
    whenever(mockWiFiPairingService.isTrackMdnsServiceAvailable()).thenReturn(true)
    whenever(mockWiFiPairingService.checkMdnsSupport()).thenReturn(MdnsSupportState.Supported)
    val service1 = createMdnsTlsService("service1", "192.168.1.101", 5555, model = null)
    val service2 = createMdnsTlsService("service2", "192.168.1.102", 5556, model = "Device A", givenName = null)
    val service3 = createMdnsTlsService("service3", "192.168.1.103", 5557, model = "Device B", givenName = "Foo Pixel")
    adblibMdnsServicesFlow.value = MdnsServices(emptyList(), listOf(service1, service2, service3), emptyList())
    composeTestRule.setContent { wifiAvailableDevicesDialog.WifiDialog() }

    composeTestRule.onNodeWithText("Unknown").assertIsDisplayed()
    composeTestRule.onNodeWithText("192.168.1.101:5555").assertIsDisplayed()

    composeTestRule.onNodeWithText("Device A").assertIsDisplayed()
    composeTestRule.onNodeWithText("192.168.1.102:5556").assertIsDisplayed()

    composeTestRule.onNodeWithText("Foo Pixel").assertIsDisplayed()
    composeTestRule.onNodeWithText("192.168.1.103:5557").assertIsDisplayed()
  }

  @Test
  fun deviceNeedsUpdate_showsWarningTooltip() = runTest {
    whenever(mockWiFiPairingService.checkMdnsSupport()).thenReturn(MdnsSupportState.Supported)
    whenever(mockWiFiPairingService.isTrackMdnsServiceAvailable()).thenReturn(true)
    val needsUpdateService = createMdnsTlsService("service1", "192.168.1.101", 5555, "Old Device", "30", mdnsServiceVersion = "1")
    adblibMdnsServicesFlow.value = MdnsServices(emptyList(), listOf(needsUpdateService), emptyList())

    composeTestRule.setContent { wifiAvailableDevicesDialog.WifiDialog() }

    composeTestRule.onNode(hasTestTag(WARNING_TOOLTIP_TEST_TAG), useUnmergedTree = true).lingerMouseHover(composeTestRule)

    composeTestRule.onNodeWithText("ADB Wi-Fi 1.0 Device").assertIsDisplayed()
    composeTestRule
      .onNodeWithText(
        "ADB Wi-Fi v1.0 has limited pairing capability. Update device to the latest API to use ADB Wi-Fi 2.0 or higher. Note: Some hardware may not support the latest API version."
      )
      .assertIsDisplayed()
    composeTestRule.onNodeWithText("Learn More").assertIsDisplayed()
  }

  @Test
  fun deviceNeedsUpdate_incorrectVersion_showsWarningTooltip() = runTest {
    whenever(mockWiFiPairingService.checkMdnsSupport()).thenReturn(MdnsSupportState.Supported)
    whenever(mockWiFiPairingService.isTrackMdnsServiceAvailable()).thenReturn(true)
    val needsUpdateService =
      createMdnsTlsService(
        "service1",
        "192.168.1.101",
        5555,
        "Old Device",
        "30",
        // We had a bug in certain devices where we show this version
        mdnsServiceVersion = "ADB_SECURE_SERVICE_VERSION",
      )
    adblibMdnsServicesFlow.value = MdnsServices(emptyList(), listOf(needsUpdateService), emptyList())

    composeTestRule.setContent { wifiAvailableDevicesDialog.WifiDialog() }

    composeTestRule.onNode(hasTestTag(WARNING_TOOLTIP_TEST_TAG), useUnmergedTree = true).lingerMouseHover(composeTestRule)

    composeTestRule.onNodeWithText("ADB Wi-Fi 1.0 Device").assertIsDisplayed()
    composeTestRule
      .onNodeWithText(
        "ADB Wi-Fi v1.0 has limited pairing capability. Update device to the latest API to use ADB Wi-Fi 2.0 or higher. Note: Some hardware may not support the latest API version."
      )
      .assertIsDisplayed()
    composeTestRule.onNodeWithText("Learn More").assertIsDisplayed()
  }

  @Test
  fun deviceUpToDate_dontShowWarning() = runTest {
    whenever(mockWiFiPairingService.checkMdnsSupport()).thenReturn(MdnsSupportState.Supported)
    whenever(mockWiFiPairingService.isTrackMdnsServiceAvailable()).thenReturn(true)
    val deviceUpToDate = createMdnsTlsService("service1", "192.168.1.101", 5555, "New Device", "30", mdnsServiceVersion = "2.0")
    adblibMdnsServicesFlow.value = MdnsServices(emptyList(), listOf(deviceUpToDate), emptyList())

    composeTestRule.setContent { wifiAvailableDevicesDialog.WifiDialog() }

    composeTestRule.onNode(hasTestTag(WARNING_TOOLTIP_TEST_TAG), useUnmergedTree = true).assertDoesNotExist()
  }

  @Test
  fun deviceUpToDate_version2_1_dontShowWarning() = runTest {
    whenever(mockWiFiPairingService.checkMdnsSupport()).thenReturn(MdnsSupportState.Supported)
    whenever(mockWiFiPairingService.isTrackMdnsServiceAvailable()).thenReturn(true)
    val deviceUpToDate = createMdnsTlsService("service1", "192.168.1.101", 5555, "New Device", "30", mdnsServiceVersion = "2.1")
    adblibMdnsServicesFlow.value = MdnsServices(emptyList(), listOf(deviceUpToDate), emptyList())

    composeTestRule.setContent { wifiAvailableDevicesDialog.WifiDialog() }

    composeTestRule.onNode(hasTestTag(WARNING_TOOLTIP_TEST_TAG), useUnmergedTree = true).assertDoesNotExist()
  }

  @Test
  fun deviceUpToDate_version10_dontShowWarning() = runTest {
    whenever(mockWiFiPairingService.checkMdnsSupport()).thenReturn(MdnsSupportState.Supported)
    whenever(mockWiFiPairingService.isTrackMdnsServiceAvailable()).thenReturn(true)
    val deviceUpToDate = createMdnsTlsService("service1", "192.168.1.101", 5555, "New Device", "30", mdnsServiceVersion = "10.0")
    adblibMdnsServicesFlow.value = MdnsServices(emptyList(), listOf(deviceUpToDate), emptyList())

    composeTestRule.setContent { wifiAvailableDevicesDialog.WifiDialog() }

    composeTestRule.onNode(hasTestTag(WARNING_TOOLTIP_TEST_TAG), useUnmergedTree = true).assertDoesNotExist()
  }

  @Test
  fun mdnsSupported_filtersOutEmulators() = runTest {
    whenever(mockWiFiPairingService.isTrackMdnsServiceAvailable()).thenReturn(true)
    whenever(mockWiFiPairingService.checkMdnsSupport()).thenReturn(MdnsSupportState.Supported)
    val service = createMdnsTlsService("adb-EMULATOR2342-ABCDEF", "192.168.1.101", 5555, "Device A", "30")
    adblibMdnsServicesFlow.value = MdnsServices(emptyList(), listOf(service), emptyList())
    composeTestRule.setContent { wifiAvailableDevicesDialog.WifiDialog() }

    composeTestRule.onNodeWithText("No devices found.", substring = true).assertIsDisplayed()
  }

  @Test
  fun mdnsVersionDisplay_nullVersion() = runTest {
    whenever(mockWiFiPairingService.isTrackMdnsServiceAvailable()).thenReturn(true)
    whenever(mockWiFiPairingService.checkMdnsSupport()).thenReturn(MdnsSupportState.Supported)
    val service = createMdnsTlsService("service1", "555.55.5555.55", 5555, mdnsServiceVersion = null)
    adblibMdnsServicesFlow.value = MdnsServices(emptyList(), listOf(service), emptyList())
    composeTestRule.setContent { wifiAvailableDevicesDialog.WifiDialog() }

    composeTestRule.onNodeWithText("v1.0").assertIsDisplayed()
  }

  @Test
  fun mdnsVersionDisplay_blankVersion() = runTest {
    whenever(mockWiFiPairingService.isTrackMdnsServiceAvailable()).thenReturn(true)
    whenever(mockWiFiPairingService.checkMdnsSupport()).thenReturn(MdnsSupportState.Supported)
    val service = createMdnsTlsService("service1", "555.55.5555.55", 5555, mdnsServiceVersion = "")
    adblibMdnsServicesFlow.value = MdnsServices(emptyList(), listOf(service), emptyList())
    composeTestRule.setContent { wifiAvailableDevicesDialog.WifiDialog() }

    composeTestRule.onNodeWithText("v1.0").assertIsDisplayed()
  }

  @Test
  fun mdnsVersionDisplay_invalidDouble() = runTest {
    whenever(mockWiFiPairingService.isTrackMdnsServiceAvailable()).thenReturn(true)
    whenever(mockWiFiPairingService.checkMdnsSupport()).thenReturn(MdnsSupportState.Supported)
    val service = createMdnsTlsService("service1", "555.55.5555.55", 5555, mdnsServiceVersion = "ADB_SECURE_SERVICE_VERSION")
    adblibMdnsServicesFlow.value = MdnsServices(emptyList(), listOf(service), emptyList())
    composeTestRule.setContent { wifiAvailableDevicesDialog.WifiDialog() }

    composeTestRule.onNodeWithText("v1.0").assertIsDisplayed()
  }

  @Test
  fun mdnsVersionDisplay_validDouble_1() = runTest {
    whenever(mockWiFiPairingService.isTrackMdnsServiceAvailable()).thenReturn(true)
    whenever(mockWiFiPairingService.checkMdnsSupport()).thenReturn(MdnsSupportState.Supported)
    val service = createMdnsTlsService("service1", "555.55.5555.55", 5555, mdnsServiceVersion = "1")
    adblibMdnsServicesFlow.value = MdnsServices(emptyList(), listOf(service), emptyList())
    composeTestRule.setContent { wifiAvailableDevicesDialog.WifiDialog() }

    composeTestRule.onNodeWithText("v1.0").assertIsDisplayed()
  }

  @Test
  fun mdnsVersionDisplay_validDouble_2_0() = runTest {
    whenever(mockWiFiPairingService.isTrackMdnsServiceAvailable()).thenReturn(true)
    whenever(mockWiFiPairingService.checkMdnsSupport()).thenReturn(MdnsSupportState.Supported)
    val service = createMdnsTlsService("service1", "555.55.5555.55", 5555, mdnsServiceVersion = "2.0")
    adblibMdnsServicesFlow.value = MdnsServices(emptyList(), listOf(service), emptyList())
    composeTestRule.setContent { wifiAvailableDevicesDialog.WifiDialog() }

    composeTestRule.onNodeWithText("v2.0").assertIsDisplayed()
  }

  @Test
  fun mdnsVersionDisplay_validDouble_2_1() = runTest {
    whenever(mockWiFiPairingService.isTrackMdnsServiceAvailable()).thenReturn(true)
    whenever(mockWiFiPairingService.checkMdnsSupport()).thenReturn(MdnsSupportState.Supported)
    val service = createMdnsTlsService("service1", "555.55.5555.55", 5555, mdnsServiceVersion = "2.1")
    adblibMdnsServicesFlow.value = MdnsServices(emptyList(), listOf(service), emptyList())
    composeTestRule.setContent { wifiAvailableDevicesDialog.WifiDialog() }

    composeTestRule.onNodeWithText("v2.1").assertIsDisplayed()
  }

  @Test
  fun mdnsSupported_addDevice_updatesTable() = runTest {
    whenever(mockWiFiPairingService.isTrackMdnsServiceAvailable()).thenReturn(true)
    whenever(mockWiFiPairingService.checkMdnsSupport()).thenReturn(MdnsSupportState.Supported)
    adblibMdnsServicesFlow.value = MdnsServices(emptyList(), emptyList(), emptyList())
    composeTestRule.setContent { wifiAvailableDevicesDialog.WifiDialog() }

    composeTestRule.onNodeWithText("No devices found.", substring = true).assertIsDisplayed()

    val service1 = createMdnsTlsService("service1", "192.168.1.101", 5555, "Device A", "30")
    adblibMdnsServicesFlow.value = MdnsServices(emptyList(), listOf(service1), emptyList())

    composeTestRule.onNodeWithText("Device A").assertIsDisplayed()
    composeTestRule.onNodeWithText("192.168.1.101:5555").assertIsDisplayed()
  }

  @Test
  fun mdnsSupported_removeDevice_updatesTable() = runTest {
    whenever(mockWiFiPairingService.isTrackMdnsServiceAvailable()).thenReturn(true)
    whenever(mockWiFiPairingService.checkMdnsSupport()).thenReturn(MdnsSupportState.Supported)
    val service1 = createMdnsTlsService("service1", "192.168.1.101", 5555, "Device A", "30")
    adblibMdnsServicesFlow.value = MdnsServices(emptyList(), listOf(service1), emptyList())
    composeTestRule.setContent { wifiAvailableDevicesDialog.WifiDialog() }

    composeTestRule.onNodeWithText("Device A").assertIsDisplayed()

    adblibMdnsServicesFlow.value = MdnsServices(emptyList(), emptyList(), emptyList())
    composeTestRule.onNodeWithText("No devices found.", substring = true).assertIsDisplayed()
    composeTestRule.onNodeWithText("Device A").assertDoesNotExist()
  }

  @Test
  fun searchFunctionality_filtersDevices() = runTest {
    whenever(mockWiFiPairingService.isTrackMdnsServiceAvailable()).thenReturn(true)
    whenever(mockWiFiPairingService.checkMdnsSupport()).thenReturn(MdnsSupportState.Supported)
    val service1 = createMdnsTlsService("service1", "192.168.1.101", 5555, "Device Alpha", "30")
    val service2 = createMdnsTlsService("service2", "192.168.1.102", 5556, "Device Beta", "31")
    adblibMdnsServicesFlow.value = MdnsServices(emptyList(), listOf(service1, service2), emptyList())
    composeTestRule.setContent { wifiAvailableDevicesDialog.WifiDialog() }

    composeTestRule.onNodeWithText("Device Alpha").assertIsDisplayed()
    composeTestRule.onNodeWithText("Device Beta").assertIsDisplayed()

    composeTestRule.onNode(hasTestTag(SEARCH_BAR_TEST_TAG) and isEditable(), useUnmergedTree = true).performTextInput("Alpha")

    composeTestRule.onNodeWithText("Device Alpha").assertIsDisplayed()
    composeTestRule.onNodeWithText("Device Beta").assertDoesNotExist()

    composeTestRule.onNodeWithContentDescription("Clear search", useUnmergedTree = true).performClick()

    composeTestRule.onNodeWithText("Device Alpha").assertIsDisplayed()
    composeTestRule.onNodeWithText("Device Beta").assertIsDisplayed()
  }

  @Test
  fun pairButtonClick_invokesPairingController() = runTest {
    whenever(mockWiFiPairingService.checkMdnsSupport()).thenReturn(MdnsSupportState.Supported)
    whenever(mockWiFiPairingService.isTrackMdnsServiceAvailable()).thenReturn(true)
    val service1 = createMdnsTlsService("service1", "192.168.1.101", 5555, "Device A", "30", mdnsServiceVersion = "2.0")
    adblibMdnsServicesFlow.value = MdnsServices(emptyList(), listOf(service1), emptyList())

    // Ensure PairDevicesUsingWiFiService is mocked correctly for the dialog instance
    composeTestRule.setContent { wifiAvailableDevicesDialog.WifiDialog() }

    composeTestRule.onNodeWithContentDescription("pair device over wifi", useUnmergedTree = true).performClick()

    val expectedTrackingMdnsService =
      TrackingMdnsService(
        serviceName = "service1",
        ipv4 = "192.168.1.101",
        port = "5555",
        deviceName = "Device A",
        mdnsServiceVersion = "2.0",
      )

    verify(mockPairDevicesUsingWiFiService)
      .createPairingDialogController(argThat { serviceName == expectedTrackingMdnsService.serviceName })
    verify(mockPairingDialogController).showDialog()
  }

  @Test
  fun refreshButton_rechecksSupport() = runTest {
    // Initial state: Not Supported
    whenever(mockWiFiPairingService.checkMdnsSupport()).thenReturn(MdnsSupportState.NotSupported)
    composeTestRule.setContent { wifiAvailableDevicesDialog.WifiDialog() }

    composeTestRule.onNodeWithText("Refresh").assertIsDisplayed()

    // Change mock to Supported
    whenever(mockWiFiPairingService.checkMdnsSupport()).thenReturn(MdnsSupportState.Supported)
    whenever(mockWiFiPairingService.isTrackMdnsServiceAvailable()).thenReturn(true)

    // Click Refresh
    composeTestRule.onNodeWithText("Refresh").performClick()

    // Expect: Supported UI (e.g. "No devices found" if list empty)
    composeTestRule.onNodeWithText("No devices found.", substring = true).assertIsDisplayed()
  }
}
