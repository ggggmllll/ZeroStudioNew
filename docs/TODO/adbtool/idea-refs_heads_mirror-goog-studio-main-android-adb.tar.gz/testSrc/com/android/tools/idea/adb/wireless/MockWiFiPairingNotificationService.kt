/*
 * Copyright (C) 2020 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.android.tools.idea.adb.wireless

import com.android.annotations.concurrency.UiThread
import com.android.tools.idea.FutureValuesTracker
import com.intellij.notification.NotificationType
import com.intellij.openapi.actionSystem.AnAction
import com.intellij.openapi.project.Project
import javax.swing.Icon

@UiThread
class MockWiFiPairingNotificationService(override val project: Project) : WiFiPairingNotificationService {
  private val delegateService = WiFiPairingNotificationServiceImpl(project)
  val showBalloonTracker = FutureValuesTracker<ShowBalloonParams>()

  override fun showBalloon(title: String, content: String, type: NotificationType, icon: Icon?, actions: List<AnAction>) {
    delegateService.showBalloon(title, content, type, icon)
    showBalloonTracker.produce(ShowBalloonParams(title, content, type, icon))
  }

  data class ShowBalloonParams(val title: String, val content: String, val type: NotificationType, val icon: Icon?)
}
