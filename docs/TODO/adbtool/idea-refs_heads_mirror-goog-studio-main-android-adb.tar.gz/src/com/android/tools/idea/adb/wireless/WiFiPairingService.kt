/*
 * Copyright (C) 2020 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.android.tools.idea.adb.wireless

import com.android.adblib.MdnsServices
import com.android.adblib.MdnsTrackServiceInfo
import com.android.annotations.concurrency.AnyThread
import com.android.repository.Revision
import com.google.common.util.concurrent.ListenableFuture
import java.awt.Color
import java.awt.image.BufferedImage
import java.net.InetAddress
import kotlinx.coroutines.flow.Flow

/** Service to expose and pair wireless devices. All entry points run asynchronously and return [ListenableFuture] for completion. */
@AnyThread
interface WiFiPairingService {
  /**
   * Returns a [MdnsSupportState] for the current platform and current ADB version.
   *
   * Errors generally are represented by states in MdnsSupportState, not exceptions, except for catastrophic failures (e.g. out of memory)
   */
  suspend fun checkMdnsSupport(): MdnsSupportState

  /** Generates a new [QrCodeImage] instance, with a new random service name and password */
  suspend fun generateQrCode(backgroundColor: Color, foregroundColor: Color): QrCodeImage

  /** Returns a snapshot of the list of [AdbDevice] currently known */
  fun devices(): ListenableFuture<List<AdbDevice>>

  /** Look up the list of mDNS services currently seen by the underlying adb implementation */
  suspend fun scanMdnsServices(): List<PairingMdnsService>

  /**
   * Returns a [Flow] that emits a new [MdnsServices] everytime a mdns service change is detected by the ADB Host
   * ("host:track-mdns-services" query). The flow is active until an exception is thrown or cancellation is requested by the flow consumer.
   */
  fun trackMdnsServices(): Flow<MdnsServices>

  /** Pair a device through an mDNS service */
  suspend fun pairMdnsService(pairingMdnsService: PairingMdnsService, password: String): PairingResult

  /** Wait for device to be available from the underlying adb implementation */
  suspend fun waitForDevice(pairingResult: PairingResult): AdbOnlineDevice

  /** Get version of ADB */
  suspend fun getAdbVersion(): String

  /** Checks if "host:track-mdns-services" is available */
  suspend fun isTrackMdnsServiceAvailable(): Boolean
}

/** Result of pairing a device through "adb pair" */
data class PairingResult(
  /** The IP address of the device that was paired */
  val ipAddress: InetAddress,
  /** The TCP port that was used for pairing */
  val port: Int,
  /** The ID of the mDNS service representing the device that was paired (e.g. "adb-939AX05XBZ-vWgJpq") */
  val mdnsServiceId: String,
) {
  /** A user friendly string representation of the device */
  val displayString: String
    get() {
      return ipAddress.hostAddress + ":" + port
    }
}

/** An adb-tls-pairing._tcp. service as exposed by the "adb mdns services" command */
data class PairingMdnsService(
  val serviceName: String,
  val serviceType: ServiceType,
  val ipAddress: InetAddress,
  val port: Int,
  val serial: String?,
) {
  /** A user friendly string representation of the device */
  val displayString: String
    get() {
      return ipAddress.hostAddress + ":" + port
    }
}

enum class ServiceType {
  QrCode,
  PairingCode,
}

/** mdns tracking service result as exposed by "host:track-mdns-services" query */
data class TrackingMdnsService(
  val serviceName: String,
  val ipv4: String,
  val port: String,
  val deviceName: String?,
  val mdnsServiceVersion: String?,
) {
  val displayString: String
    get() {
      return if (deviceName.isNullOrBlank()) "Device" else deviceName
    }
}

internal fun TrackingMdnsService.needsUpdate(): Boolean {
  return mdnsServiceNeedsUpdate(mdnsServiceVersion)
}

internal fun MdnsTrackServiceInfo.needsUpdate(): Boolean {
  return mdnsServiceNeedsUpdate(mdnsServiceVersion)
}

// minimum mdns version is 2.0 to work with new adb wifi v2 features.
private fun mdnsServiceNeedsUpdate(mdnsServiceVersion: String?): Boolean {
  val version = mdnsServiceVersion?.toDoubleOrNull() ?: return true
  return version < 2.0
}

/** Abstraction over an bitmap representation of a QrCode */
data class QrCodeImage(
  /** The service name of this QR Code. This name will be exposed by ADB when the phone is ready to pair. */
  val serviceName: String,
  /** The password of this QR Code. This password will be used when pairing the device. */
  val password: String,
  /** The full pairing string, i.e. the string that is encoded in the [image] */
  val pairingString: String,
  /**
   * The QR Code [BufferedImage] representing [pairingString].
   *
   * The image has a white background and a black pixel for each QR Code "dot". There is also a white border of a few pixel wide around the
   * image to allow for cameras to frame the QR Code.
   */
  val image: BufferedImage,
)

enum class MdnsSupportState {
  /** mDNS is supported on the current platform with the current version of ADB */
  Supported,

  /** mDNS is not supported on the current platform, even though ADB is of the right version */
  NotSupported,

  /** ADB version is outdated, it does not support mDNS */
  AdbVersionTooLow,

  /** There was an error invoking ADB, so we don't know if mDNS is supported or not */
  AdbInvocationError,

  /** ADB server MDNS is disabled */
  AdbDisabled,
}

// ADB version 37.0.0 or higher is required for reliable ADB Wi-Fi v2 improvements.
fun isAdbVersionTooLow(adbVersion: String): Boolean {
  val version = Revision.safeParseRevision(adbVersion.substringBefore('-'))
  return version < Revision(37, 0, 0)
}
