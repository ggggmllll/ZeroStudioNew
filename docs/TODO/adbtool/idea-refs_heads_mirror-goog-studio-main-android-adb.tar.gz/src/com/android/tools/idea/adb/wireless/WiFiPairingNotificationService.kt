/*
 * Copyright (C) 2020 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.android.tools.idea.adb.wireless

import com.android.annotations.concurrency.UiThread
import com.android.tools.idea.adb.wireless.v2.ui.WifiAvailableDevicesDialog
import com.intellij.notification.NotificationAction
import com.intellij.notification.NotificationType
import com.intellij.openapi.actionSystem.AnAction
import com.intellij.openapi.project.Project
import icons.StudioIcons
import javax.swing.Icon

/** Service responsible for showing notification popups related to ADB device pairing (see [WiFiPairingController]) */
interface WiFiPairingNotificationService {

  val project: Project

  @UiThread fun showBalloon(title: String, content: String, type: NotificationType, icon: Icon?, actions: List<AnAction> = emptyList())
}

fun WiFiPairingNotificationService.showPairingSuccessBalloon(device: AdbOnlineDevice) {
  showBalloon(
    "${device.displayString} connected over Wi-Fi",
    "The device is now available to use.",
    NotificationType.INFORMATION,
    StudioIcons.Common.SUCCESS,
  )
}

fun WiFiPairingNotificationService.showDeviceHiddenBalloon(deviceName: String?) {
  showBalloon(
    "${deviceName ?: "Device"} is now hidden",
    "You can view and pair all devices by using the Wi-Fi pairing dialog.",
    NotificationType.INFORMATION,
    StudioIcons.Common.SUCCESS,
    listOf(
      NotificationAction.createExpiring("Open wifi-pairing dialog") { _, _ ->
        val wifiPairingService = WiFiPairingServiceImpl(RandomProvider(), AdbServiceWrapperAdbLibImpl(project))
        WifiAvailableDevicesDialog(project, wifiPairingService).showDialog()
      }
    ),
  )
}
