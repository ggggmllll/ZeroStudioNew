/*
 * Copyright (C) 2021 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.android.tools.idea.gradle.dsl.api.settings;

import com.android.tools.idea.gradle.dsl.api.util.GradleBlockModel;
import com.android.tools.idea.gradle.dsl.model.settings.FromCatalogResolvedProperty;
import org.jetbrains.annotations.NotNull;

public interface VersionCatalogModel extends GradleBlockModel {
  String DEFAULT_CATALOG_NAME = "libs";
  String DEFAULT_CATALOG_FILE_NAME = "libs.versions.toml";
  String DEFAULT_CATALOG_FILE = "gradle/" + DEFAULT_CATALOG_FILE_NAME;
  enum VersionCatalogSource {
    FILES, IMPORTED
  }

  @NotNull
  String getName();

  /**
   * Returns instance of FromCatalogResolvedProperty that is child of ResolvedProperty.
   * It can be literal for imported catalog, or files("...") for catalog location.
   * For new catalog model and for libs - it has `files` type
   *
   * @return a resolved property model
   */
  @NotNull
  FromCatalogResolvedProperty from();
}
