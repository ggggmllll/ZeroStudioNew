androidApp {
  dependenciesDcl {
    compile("[]#$a")
  }
}
