dependencies {
  compile("[]#$a")
}
