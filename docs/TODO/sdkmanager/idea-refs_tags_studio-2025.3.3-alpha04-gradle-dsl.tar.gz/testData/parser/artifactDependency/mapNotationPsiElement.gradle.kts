dependencies {
  compile(group="com.google.code.guice", name="guice", version="1.0", classifier="high", ext="bleh")
}
