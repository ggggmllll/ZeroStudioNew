dependencies {
  compile(name="name")
}
