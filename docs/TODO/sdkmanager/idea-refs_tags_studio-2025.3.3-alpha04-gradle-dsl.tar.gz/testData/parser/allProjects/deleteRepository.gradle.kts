allprojects {
  repositories {
    jcenter()
    google()
  }
}
