plugins {
  id("kotlin-android")
  id("kotlin-plugin-extensions")
  id("some-other-plugin")
}
allprojects {
  repositories {
    jcenter()
  }
}
repositories {
  google()
}
