buildscript {
  extra["hello"] = "boo"
}
