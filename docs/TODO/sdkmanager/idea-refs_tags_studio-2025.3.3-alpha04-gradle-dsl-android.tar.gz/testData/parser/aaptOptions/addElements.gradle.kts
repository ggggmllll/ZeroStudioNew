android {
  aaptOptions {
  }
}
