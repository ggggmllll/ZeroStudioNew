android {
  buildTypes {
    create("xyz") {
    }
  }
}
