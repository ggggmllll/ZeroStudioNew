android {
  buildTypes {
    create("xyz") {
    }
  }
}