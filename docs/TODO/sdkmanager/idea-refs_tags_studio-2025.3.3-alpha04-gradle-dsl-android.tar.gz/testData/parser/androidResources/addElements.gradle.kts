android {
  androidResources {
  }
}
