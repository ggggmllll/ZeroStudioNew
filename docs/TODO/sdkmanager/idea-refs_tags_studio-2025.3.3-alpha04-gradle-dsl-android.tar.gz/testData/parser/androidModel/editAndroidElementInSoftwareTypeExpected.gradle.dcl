androidApp {
   namespace = "bcd"
}