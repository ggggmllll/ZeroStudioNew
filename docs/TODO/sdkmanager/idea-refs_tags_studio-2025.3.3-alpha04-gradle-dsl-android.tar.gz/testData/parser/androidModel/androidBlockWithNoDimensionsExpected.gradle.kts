android {
  flavorDimensions += listOf("strawberry")
}
