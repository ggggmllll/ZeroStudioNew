android {
  buildTypes {
    create("all") {
      applicationIdSuffix = "foo"
    }
  }
}
