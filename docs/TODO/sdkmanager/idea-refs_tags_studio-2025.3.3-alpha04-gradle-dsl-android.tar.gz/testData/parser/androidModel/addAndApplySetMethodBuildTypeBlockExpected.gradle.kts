android {
  buildTypes {
    create("of") {
      applicationIdSuffix = "foo"
    }
  }
}
