android {
  compileSdk = 36
  compileSdkMinor = 1
  compileSdkExtension = 2
}