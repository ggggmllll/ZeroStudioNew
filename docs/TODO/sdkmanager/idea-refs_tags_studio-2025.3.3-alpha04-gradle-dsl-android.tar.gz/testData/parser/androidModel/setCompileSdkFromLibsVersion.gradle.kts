android {
  compileSdk = libs.versions.compileSdk.get().toInt()
}