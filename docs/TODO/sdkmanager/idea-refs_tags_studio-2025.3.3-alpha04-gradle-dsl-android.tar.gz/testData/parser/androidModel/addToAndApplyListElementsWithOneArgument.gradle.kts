android {
  flavorDimensions("abi")
}
