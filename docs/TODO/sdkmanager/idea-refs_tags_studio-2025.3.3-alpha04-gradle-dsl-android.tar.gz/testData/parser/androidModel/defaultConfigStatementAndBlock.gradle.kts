android.defaultConfig.applicationId = "abc.def"
android.defaultConfig {
  applicationIdSuffix = "xyz"
}
