
androidApp {
  compileSdkVersion = "android-S"
}