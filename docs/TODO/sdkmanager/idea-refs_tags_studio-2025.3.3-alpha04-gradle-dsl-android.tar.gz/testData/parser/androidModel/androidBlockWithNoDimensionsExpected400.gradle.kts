android {
  flavorDimensions("strawberry")
}
