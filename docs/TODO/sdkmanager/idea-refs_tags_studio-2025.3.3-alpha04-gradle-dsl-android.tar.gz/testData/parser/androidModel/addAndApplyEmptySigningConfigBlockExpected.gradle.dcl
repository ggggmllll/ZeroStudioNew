androidApp {
  signingConfigs {
    signingConfig("config") {
    }
  }
}