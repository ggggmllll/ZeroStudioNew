android {
  defaultConfig {
    applicationId = "foo.bar"
  }
}
