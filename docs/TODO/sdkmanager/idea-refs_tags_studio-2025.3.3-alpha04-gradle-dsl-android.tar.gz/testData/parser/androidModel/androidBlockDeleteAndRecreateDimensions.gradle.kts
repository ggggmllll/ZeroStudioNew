android {
  flavorDimensions("salt", "sugar")
}
