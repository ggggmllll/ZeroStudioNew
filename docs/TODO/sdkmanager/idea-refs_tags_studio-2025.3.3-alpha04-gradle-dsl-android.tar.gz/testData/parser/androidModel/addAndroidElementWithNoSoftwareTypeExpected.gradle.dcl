androidApp {
  defaultPublishConfig = "debug"
}