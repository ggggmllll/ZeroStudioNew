android {
  buildTypes {
    create("create") {
      applicationIdSuffix = "foo"
    }
  }
}
