android {
  signingConfigs {
    create("config") {
    }
  }
}
