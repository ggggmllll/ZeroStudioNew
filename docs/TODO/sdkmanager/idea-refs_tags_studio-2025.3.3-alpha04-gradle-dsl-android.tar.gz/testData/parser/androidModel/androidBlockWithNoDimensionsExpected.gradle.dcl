androidApp {
  flavorDimensions += listOf("strawberry")
}
