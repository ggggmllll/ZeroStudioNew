android {
  flavorDimensions("abi", "version")
}
