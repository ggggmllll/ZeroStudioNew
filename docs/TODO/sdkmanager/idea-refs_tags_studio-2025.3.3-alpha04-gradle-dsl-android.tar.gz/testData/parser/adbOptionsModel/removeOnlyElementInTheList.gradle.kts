android {
  adbOptions {
    installOptions("abcd")
  }
}
