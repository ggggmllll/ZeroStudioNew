android {
  adbOptions {
    installOptions("efgh")
  }
}
