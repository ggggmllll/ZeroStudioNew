android {
  adbOptions {
    installOptions("abcd", "efgh")
  }
}
