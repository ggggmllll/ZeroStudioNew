/*
 * Copyright (C) 2022 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.android.ide.gradle.model.impl

import com.android.ide.gradle.model.LegacyAndroidGradlePluginProperties
import java.io.File

data class LegacyAndroidGradlePluginPropertiesImpl(
  override val componentToApplicationIdMap: Map<String, String>,
  override val namespace: String?,
  override val androidTestNamespace: String?,
  override val dataBindingEnabled: Boolean?,
  override val problems: List<Exception>,
  override val mappingR8TextFiles: Map<String, File?>,
  override val buildTypesMatchingFallbacks: Map<String, List<String>>,
  override val productFlavorsMatchingFallbacks: Map<String, List<String>>,
  override val missingDimensionStrategies: Map<String, Map<String, List<String>>>,
) : LegacyAndroidGradlePluginProperties
