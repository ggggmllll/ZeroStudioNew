/*
 * Copyright (C) 2023 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.android.ide.gradle.model

/** Contains Gradle properties that Studio is interested in. */
interface GradlePropertiesModel {

  /** Whether AndroidX libraries should be used instead of legacy support libraries. */
  val useAndroidX: Boolean?

  /** Whether constraints for library components are disabled */
  val excludeLibraryComponentsFromConstraints: Boolean?

  /** Whether to generate manifest classes. */
  val generateManifestClass: Boolean?

  /** Whether to disable Android Gradle plugin upgrade prompt */
  val disableAgpUpgradePrompt: Boolean?

  /** Whether to use Gradle managed devices. */
  val useCustomManagedDevices: Boolean?

  val buildInKotlinDefaultEnabled: Boolean?
}
