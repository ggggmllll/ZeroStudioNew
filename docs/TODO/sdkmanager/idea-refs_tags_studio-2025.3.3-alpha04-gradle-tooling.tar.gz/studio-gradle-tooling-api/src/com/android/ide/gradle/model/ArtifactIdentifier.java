/*
 * Copyright (C) 2020 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.android.ide.gradle.model;

import com.android.ide.gradle.model.artifacts.AdditionalClassifierArtifacts;
import org.jetbrains.annotations.NotNull;

/**
 * The unique identifier of {@link AdditionalClassifierArtifacts}
 */
public interface ArtifactIdentifier {
  /**
   * Returns the name of the artifact's group.
   */
  @NotNull
  String getGroupId();

  /**
   * Returns the name that the artifact is known by.
   */
  @NotNull
  String getArtifactId();

  /**
   * Returns the version of the artifact.
   */
  @NotNull
  String getVersion();
}