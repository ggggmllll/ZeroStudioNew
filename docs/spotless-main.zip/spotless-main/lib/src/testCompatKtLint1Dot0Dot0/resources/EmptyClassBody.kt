class EmptyClassBody {

}
