package android.zero.studio.terminal.io;

import android.annotation.SuppressLint;
import android.view.Gravity;
import android.view.View;
import androidx.annotation.NonNull;
import androidx.drawerlayout.widget.DrawerLayout;

import android.zero.studio.terminal.TermuxFragment;
import android.zero.studio.terminal.terminal.TermuxTerminalSessionFragmentClient;
import android.zero.studio.terminal.terminal.TermuxTerminalViewClient;

import com.termux.shared.logger.Logger;
import com.termux.shared.termux.extrakeys.ExtraKeysConstants;
import com.termux.shared.termux.extrakeys.ExtraKeysInfo;
import com.termux.shared.termux.settings.properties.TermuxPropertyConstants;
import com.termux.shared.termux.settings.properties.TermuxSharedProperties;
import com.termux.shared.termux.terminal.io.TerminalExtraKeys;
import com.termux.view.TerminalView;
import org.json.JSONException;

/**
 * An implementation of {@link TerminalExtraKeys} that handles Termux-specific extra key actions.
 * This class has been refactored to depend on {@link TermuxFragment} instead of a concrete Activity,
 * allowing it to be hosted in a flexible UI.
 */
public class TermuxTerminalExtraKeys extends TerminalExtraKeys {

    private ExtraKeysInfo mExtraKeysInfo;

    final TermuxFragment mFragment;
    final TermuxTerminalViewClient mTermuxTerminalViewClient;
    final TermuxTerminalSessionFragmentClient mTermuxTerminalSessionFragmentClient;

    private static final String LOG_TAG = "TermuxTerminalExtraKeys";

    /**
     * Constructor for TermuxTerminalExtraKeys.
     *
     * @param fragment The hosting {@link TermuxFragment}.
     * @param terminalView The {@link TerminalView} this client is associated with.
     * @param termuxTerminalViewClient The client for terminal view events.
     * @param TermuxTerminalSessionFragmentClient The client for terminal session events.
     */
    public TermuxTerminalExtraKeys(@NonNull TermuxFragment fragment, @NonNull TerminalView terminalView,
                                   @NonNull TermuxTerminalViewClient termuxTerminalViewClient,
                                   @NonNull TermuxTerminalSessionFragmentClient TermuxTerminalSessionFragmentClient) {
        super(terminalView);

        mFragment = fragment;
        mTermuxTerminalViewClient = termuxTerminalViewClient;
        mTermuxTerminalSessionFragmentClient = TermuxTerminalSessionFragmentClient;

        setExtraKeys();
    }


    /**
     * Set the terminal extra keys and style by loading them from properties.
     */
    private void setExtraKeys() {
        mExtraKeysInfo = null;

        try {
            // The mMap stores the extra key and style string values while loading properties
            // Check {@link TermuxSharedProperties#getExtraKeysInternalPropertyValueFromValue(String)} and
            // {@link TermuxSharedProperties#getExtraKeysStyleInternalPropertyValueFromValue(String)}
            String extrakeys = (String) mFragment.getProperties().getInternalPropertyValue(TermuxPropertyConstants.KEY_EXTRA_KEYS, true);
            String extraKeysStyle = (String) mFragment.getProperties().getInternalPropertyValue(TermuxPropertyConstants.KEY_EXTRA_KEYS_STYLE, true);

            ExtraKeysConstants.ExtraKeyDisplayMap extraKeyDisplayMap = ExtraKeysInfo.getCharDisplayMapForStyle(extraKeysStyle);
            if (ExtraKeysConstants.EXTRA_KEY_DISPLAY_MAPS.DEFAULT_CHAR_DISPLAY.equals(extraKeyDisplayMap) && !TermuxPropertyConstants.DEFAULT_IVALUE_EXTRA_KEYS_STYLE.equals(extraKeysStyle)) {
                Logger.logError(TermuxSharedProperties.LOG_TAG, "The style \"" + extraKeysStyle + "\" for the key \"" + TermuxPropertyConstants.KEY_EXTRA_KEYS_STYLE + "\" is invalid. Using default style instead.");
                extraKeysStyle = TermuxPropertyConstants.DEFAULT_IVALUE_EXTRA_KEYS_STYLE;
            }

            mExtraKeysInfo = new ExtraKeysInfo(extrakeys, extraKeysStyle, ExtraKeysConstants.CONTROL_CHARS_ALIASES);
        } catch (JSONException e) {
            Logger.showToast(mFragment.requireActivity(), "Could not load and set the \"" + TermuxPropertyConstants.KEY_EXTRA_KEYS + "\" property from the properties file: " + e.toString(), true);
            Logger.logStackTraceWithMessage(LOG_TAG, "Could not load and set the \"" + TermuxPropertyConstants.KEY_EXTRA_KEYS + "\" property from the properties file: ", e);

            try {
                mExtraKeysInfo = new ExtraKeysInfo(TermuxPropertyConstants.DEFAULT_IVALUE_EXTRA_KEYS, TermuxPropertyConstants.DEFAULT_IVALUE_EXTRA_KEYS_STYLE, ExtraKeysConstants.CONTROL_CHARS_ALIASES);
            } catch (JSONException e2) {
                Logger.showToast(mFragment.requireActivity(), "Can't create default extra keys",true);
                Logger.logStackTraceWithMessage(LOG_TAG, "Could create default extra keys: ", e);
                mExtraKeysInfo = null;
            }
        }
    }

    public ExtraKeysInfo getExtraKeysInfo() {
        return mExtraKeysInfo;
    }

    @SuppressLint("RtlHardcoded")
    @Override
    public void onTerminalExtraKeyButtonClick(View view, String key, boolean ctrlDown, boolean altDown, boolean shiftDown, boolean fnDown) {
        if ("KEYBOARD".equals(key)) {
            if(mTermuxTerminalViewClient != null)
                mTermuxTerminalViewClient.onToggleSoftKeyboardRequest();
        } else if ("DRAWER".equals(key)) {
            // Directly get the drawer from the fragment instance
            DrawerLayout drawerLayout = mFragment.getDrawer();
            if (drawerLayout != null) {
                if (drawerLayout.isDrawerOpen(Gravity.LEFT))
                    drawerLayout.closeDrawer(Gravity.LEFT);
                else
                    drawerLayout.openDrawer(Gravity.LEFT);
            }
        } else if ("PASTE".equals(key)) {
            if(mTermuxTerminalSessionFragmentClient != null)
                mTermuxTerminalSessionFragmentClient.onPasteTextFromClipboard(null);
        }  else if ("SCROLL".equals(key)) {
            // The mTerminalView is available from the super class, no need to go through the client.
            if (mTerminalView != null && mTerminalView.mEmulator != null)
                mTerminalView.mEmulator.toggleAutoScrollDisabled();
        } else {
            super.onTerminalExtraKeyButtonClick(view, key, ctrlDown, altDown, shiftDown, fnDown);
        }
    }

}