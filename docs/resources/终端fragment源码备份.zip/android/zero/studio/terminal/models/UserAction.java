package android.zero.studio.terminal.models;

public enum UserAction {
  REPORT_ISSUE_FROM_TRANSCRIPT("report issue from transcript");

  private final String name;

  UserAction(final String name) {
    this.name = name;
  }

  public String getName() {
    return name;
  }

}
