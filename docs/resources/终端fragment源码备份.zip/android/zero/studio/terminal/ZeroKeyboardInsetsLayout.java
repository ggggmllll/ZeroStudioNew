package android.zero.studio.terminal;

import android.content.Context;
import android.os.Build;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsAnimationCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.List;

/**
 * A modern, high-performance replacement for the original TermuxActivityRootView.
 * This view uses the official WindowInsetsCompat and WindowInsetsAnimationCompat APIs
 * to gracefully handle soft keyboard (IME) and other system UI visibility changes,
 * ensuring content is not obscured in various windowing modes (fullscreen, split-screen, freeform).
 *
 * Key Improvements:
 * - **Performance**: Replaces the inefficient OnGlobalLayoutListener with targeted inset listeners.
 * - **Smooth Animation**: Synchronizes view translation with the keyboard's animation for a
 *   jitter-free user experience, especially on Android 11+ (API 30+).
 * - **Robustness & Compatibility**: Relies on standard Android APIs, making it more reliable
 *   across different devices and Android versions.
 * - **Decoupling**: It is a self-contained component that does not require a direct reference
 *   to a hosting Fragment or Activity.
 * - **Simplicity**: The logic is significantly simpler and easier to maintain.
 */
public class ZeroKeyboardInsetsLayout extends FrameLayout {

    public ZeroKeyboardInsetsLayout(@NonNull Context context) {
        super(context);
    }

    public ZeroKeyboardInsetsLayout(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }

    public ZeroKeyboardInsetsLayout(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        ViewCompat.requestApplyInsets(this);
        setupInsetsController();
    }

    public void setupInsetsController() {
        // This listener handles the final state of the insets.
        ViewCompat.setOnApplyWindowInsetsListener(this, (v, windowInsets) -> {
            // Get insets for system bars (status bar, navigation bar, etc.)
            Insets systemBarInsets = windowInsets.getInsets(WindowInsetsCompat.Type.systemBars());

            // Get insets for the IME (soft keyboard)
            Insets imeInsets = windowInsets.getInsets(WindowInsetsCompat.Type.ime());

            // The root view's padding should only account for system bars to prevent content
            // from drawing underneath them.
            v.setPadding(
                    systemBarInsets.left,
                    systemBarInsets.top,
                    systemBarInsets.right,
                    0 // Set bottom padding to 0, it will be handled by the child's margin.
            );

            // The effective bottom inset is the larger of the IME inset and the system bar inset.
            // This handles cases where the keyboard is hidden but the navigation bar is visible,
            // and vice-versa, including in split-screen/freeform modes.
            int effectiveBottomInset = Math.max(imeInsets.bottom, systemBarInsets.bottom);

            // Apply this effective bottom inset as a margin to the direct child view(s).
            // This pushes the entire content view (the RelativeLayout) up.
            for (int i = 0; i < getChildCount(); i++) {
                View child = getChildAt(i);
                if (child.getLayoutParams() instanceof ViewGroup.MarginLayoutParams) {
                    ViewGroup.MarginLayoutParams params = (ViewGroup.MarginLayoutParams) child.getLayoutParams();
                    params.bottomMargin = effectiveBottomInset;
                    child.setLayoutParams(params);
                }
            }

            // We have handled the insets, so consume them.
            return WindowInsetsCompat.CONSUMED;
        });

        // The animation callback remains for smooth transitions on compatible devices.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            ViewCompat.setWindowInsetsAnimationCallback(this, new InsetsAnimationCallback());
        }
    }

    @RequiresApi(Build.VERSION_CODES.R)
    public class InsetsAnimationCallback extends WindowInsetsAnimationCompat.Callback {

        private float lastFraction = 0f;
        private int startBottom = 0;
        private int endBottom = 0;

        public InsetsAnimationCallback() {
            super(DISPATCH_MODE_STOP);
        }

        @Override
        public void onPrepare(@NonNull WindowInsetsAnimationCompat animation) {
            lastFraction = 0f;
        }

        @NonNull
        @Override
        public WindowInsetsAnimationCompat.BoundsCompat onStart(@NonNull WindowInsetsAnimationCompat animation, @NonNull WindowInsetsAnimationCompat.BoundsCompat bounds) {
            startBottom = bounds.getLowerBound().bottom;
            endBottom = bounds.getUpperBound().bottom;
            return super.onStart(animation, bounds);
        }

        @NonNull
        @Override
        public WindowInsetsCompat onProgress(@NonNull WindowInsetsCompat insets, @NonNull List<WindowInsetsAnimationCompat> runningAnimations) {
            WindowInsetsAnimationCompat imeAnimation = null;
            for (WindowInsetsAnimationCompat animation : runningAnimations) {
                if ((animation.getTypeMask() & WindowInsetsCompat.Type.ime()) != 0) {
                    imeAnimation = animation;
                    break;
                }
            }

            if (imeAnimation != null) {
                float interpolatedFraction = imeAnimation.getInterpolatedFraction();
                // Check for invalid fraction
                if (interpolatedFraction < 0) {
                    interpolatedFraction = lastFraction;
                }

                // Calculate the current animated bottom inset.
                int animatedBottom = (int) (startBottom + (endBottom - startBottom) * interpolatedFraction);

                // Apply the animated value as translation to child views.
                for (int i = 0; i < ZeroKeyboardInsetsLayout.this.getChildCount(); i++) {
                    View child = ZeroKeyboardInsetsLayout.this.getChildAt(i);
                    // We translate the view *up* by the difference between the final inset
                    // and the current animated inset.
                    child.setTranslationY(-(endBottom - animatedBottom));
                }

                lastFraction = interpolatedFraction;
            }

            return insets;
        }

        @Override
        public void onEnd(@NonNull WindowInsetsAnimationCompat animation) {
            // Reset translation at the end of the animation.
            // The final margin is set by the OnApplyWindowInsetsListener.
            for (int i = 0; i < ZeroKeyboardInsetsLayout.this.getChildCount(); i++) {
                View child = ZeroKeyboardInsetsLayout.this.getChildAt(i);
                child.setTranslationY(0);
            }
        }
    }
}