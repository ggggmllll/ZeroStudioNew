/*
 *  This file is part of AndroidIDE.
 *
 *  AndroidIDE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  AndroidIDE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *   along with AndroidIDE.  If not, see <https://www.gnu.org/licenses/>.
 */

package com.itsaky.androidide.tooling.events.internal

import com.itsaky.androidide.tooling.events.FinishEvent
import com.itsaky.androidide.tooling.events.OperationDescriptor
import com.itsaky.androidide.tooling.events.OperationResult

/** @author Akash Yadav */
class DefaultFinishEvent(
    displayName: String,
    eventTime: Long,
    descriptor: OperationDescriptor,
    override val result: OperationResult,
) : DefaultProgressEvent(displayName, eventTime, descriptor), FinishEvent
