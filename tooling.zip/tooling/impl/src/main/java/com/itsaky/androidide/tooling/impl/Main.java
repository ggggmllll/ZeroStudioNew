/*
 *  This file is part of AndroidIDE.
 *
 *  AndroidIDE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  AndroidIDE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *   along with AndroidIDE.  If not, see <https://www.gnu.org/licenses/>.
 */

package com.itsaky.androidide.tooling.impl

import com.itsaky.androidide.tooling.api.GrpcConstants
import io.grpc.ServerBuilder
import java.util.concurrent.TimeUnit

object Main {
    @JvmStatic
    fun main(args: Array<String>) {
        // Disable JVM StdErr appender to keep stdout clean for the port token
        System.setProperty("com.itsaky.androidide.logging.JvmStdErrAppender.enabled", "false")

        val server = ServerBuilder.forPort(0) // Bind to any available port
            .addService(GrpcToolingServiceImpl())
            .maxInboundMessageSize(GrpcConstants.MAX_MESSAGE_SIZE)
            .build()
            .start()

        val port = server.port
        
        // Print the port token to Stdout so the Client can read it
        println("${GrpcConstants.SERVER_PORT_TOKEN}$port")
        
        // Ensure the token is flushed
        System.out.flush()

        // Keep the server running
        server.awaitTermination()
    }
}