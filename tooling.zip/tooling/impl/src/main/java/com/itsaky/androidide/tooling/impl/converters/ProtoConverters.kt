/*
 *  This file is part of AndroidIDE.
 *
 *  AndroidIDE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  AndroidIDE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *   along with AndroidIDE.  If not, see <https://www.gnu.org/licenses/>.
 */

package com.itsaky.androidide.tooling.impl.converters

import com.android.builder.model.v2.ide.AndroidArtifact
import com.android.builder.model.v2.ide.JavaArtifact
import com.android.builder.model.v2.ide.Library
import com.android.builder.model.v2.ide.Variant
import com.android.builder.model.v2.models.AndroidDsl
import com.android.builder.model.v2.models.AndroidProject
import com.android.builder.model.v2.models.BasicAndroidProject
import com.android.builder.model.v2.models.ProjectSyncIssues
import com.android.builder.model.v2.models.VariantDependencies
import com.itsaky.androidide.tooling.api.proto.AndroidArtifactMetadata
import com.itsaky.androidide.tooling.api.proto.AndroidGradlePluginFlags
import com.itsaky.androidide.tooling.api.proto.AndroidLibrary
import com.itsaky.androidide.tooling.api.proto.AndroidProjectDetail
import com.itsaky.androidide.tooling.api.proto.AndroidProjectType
import com.itsaky.androidide.tooling.api.proto.AndroidVariantMetadata
import com.itsaky.androidide.tooling.api.proto.BasicAndroidVariant
import com.itsaky.androidide.tooling.api.proto.BasicProjectMetadata
import com.itsaky.androidide.tooling.api.proto.CustomSourceDirectory
import com.itsaky.androidide.tooling.api.proto.GradleTask
import com.itsaky.androidide.tooling.api.proto.JavaCompileOptions
import com.itsaky.androidide.tooling.api.proto.ProjectType
import com.itsaky.androidide.tooling.api.proto.SourceProvider
import com.itsaky.androidide.tooling.api.proto.SourceSetContainer
import com.itsaky.androidide.tooling.api.proto.SyncIssue
import com.itsaky.androidide.tooling.api.proto.ViewBindingOptions
import org.gradle.tooling.model.GradleProject
import org.gradle.tooling.model.idea.IdeaModule
import java.io.File
import com.android.builder.model.v2.ide.ProjectType as AgpProjectType

/**
 * Utility functions to convert Gradle/AGP models to Protobuf messages.
 *
 * @author android_zero
 */
object ProtoConverters {

    fun toBasicProjectMetadata(project: GradleProject, type: ProjectType): BasicProjectMetadata {
        return BasicProjectMetadata.newBuilder()
            .setName(project.name)
            .setProjectPath(project.path)
            .setProjectDir(project.projectDirectory.absolutePath)
            .setBuildDir(project.buildDirectory.absolutePath)
            .setDescription(project.description ?: "")
            .setBuildScript(project.buildScript.sourceFile?.absolutePath ?: "")
            .setType(type)
            .build()
    }

    fun toGradleTask(task: org.gradle.tooling.model.GradleTask): GradleTask {
        return GradleTask.newBuilder()
            .setName(task.name)
            .setPath(task.path)
            .setProjectPath(task.project.path)
            .setDescription(task.description ?: "")
            .setGroup(task.group ?: "")
            .setDisplayName(task.displayName ?: "")
            .setIsPublic(task.isPublic)
            .build()
    }

    fun toSyncIssues(issues: ProjectSyncIssues): List<SyncIssue> {
        return issues.syncIssues.map { issue ->
            SyncIssue.newBuilder()
                .setMessage(issue.message)
                .setData(issue.data ?: "")
                .setSeverity(issue.severity)
                .setType(issue.type)
                .addAllMultiLineMessage(issue.multiLineMessage ?: emptyList())
                .build()
        }
    }

    fun toAndroidProjectDetail(
        basic: BasicAndroidProject,
        project: AndroidProject,
        dsl: AndroidDsl,
        deps: VariantDependencies,
        configuredVariantName: String
    ): AndroidProjectDetail {
        val builder = AndroidProjectDetail.newBuilder()

        // 1. Basic Info
        builder.namespace = project.namespace ?: ""
        builder.resourcePrefix = project.resourcePrefix ?: ""
        builder.androidTestNamespace = project.androidTestNamespace ?: ""
        builder.testFixturesNamespace = project.testFixturesNamespace ?: ""
        builder.androidType = when (basic.projectType) {
            AgpProjectType.APPLICATION -> AndroidProjectType.ANDROID_APP
            AgpProjectType.LIBRARY -> AndroidProjectType.ANDROID_LIBRARY
            AgpProjectType.TEST -> AndroidProjectType.ANDROID_TEST
            AgpProjectType.DYNAMIC_FEATURE -> AndroidProjectType.ANDROID_FEATURE
            else -> AndroidProjectType.ANDROID_APP
        }

        // 2. Flags & Options
        builder.flags = AndroidGradlePluginFlags.newBuilder()
            .putAllBooleanFlags(project.flags.booleanFlagMap.mapKeys { it.key.name }.mapValues { it.value ?: false })
            .build()
        
        project.javaCompileOptions?.let { opts ->
            builder.compileOptions = JavaCompileOptions.newBuilder()
                .setEncoding(opts.encoding)
                .setSourceCompatibility(opts.sourceCompatibility)
                .setTargetCompatibility(opts.targetCompatibility)
                .setIsCoreLibraryDesugaringEnabled(opts.isCoreLibraryDesugaringEnabled)
                .build()
        }
        
        project.viewBindingOptions?.let { opts ->
            builder.viewBindingOptions = ViewBindingOptions.newBuilder()
                .setIsEnabled(opts.isEnabled)
                .build()
        }

        // 3. Paths
        builder.addAllBootClasspaths(basic.bootClasspath.map { it.absolutePath })
        builder.addAllLintChecksJars(project.lintChecksJars.map { it.absolutePath })

        // 4. Source Sets
        basic.mainSourceSet?.let {
            builder.mainSourceSet = toSourceSetContainer(it)
        }

        // 5. Variants
        builder.configuredVariant = configuredVariant
        basic.variants.forEach { variant ->
            // Note: We only have full details for the SELECTED variant (passed via deps)
            // For others, we only have basic info from BasicAndroidProject
            builder.addVariants(BasicAndroidVariant.newBuilder()
                .setName(variant.name)
                .build())
        }

        // 6. Selected Variant Detail (Full)
        val selectedVariant = project.variants.find { it.name == configuredVariant }
        if (selectedVariant != null) {
            builder.selectedVariantDetail = toAndroidVariantMetadata(selectedVariant)
        }
        
        // 7. Libraries (Flattened from VariantDependencies)
        deps.libraries.forEach { (key, lib) ->
            builder.putLibraryMap(key, toAndroidLibrary(key, lib))
        }

        return builder.build()
    }

    private fun toAndroidVariantMetadata(variant: Variant): AndroidVariantMetadata {
        val builder = AndroidVariantMetadata.newBuilder()
        builder.name = variant.name
        builder.mainArtifact = toAndroidArtifactMetadata(variant.name, variant.mainArtifact)
        
        variant.deviceTestArtifacts.forEach { (name, artifact) ->
             builder.putOtherArtifacts(name, toAndroidArtifactMetadata(name, artifact))
        }
        // Host tests are JavaArtifacts, usually handled separately or mapped to artifacts
        
        return builder.build()
    }

    private fun toAndroidArtifactMetadata(variantName: String, artifact: AndroidArtifact): AndroidArtifactMetadata {
        val builder = AndroidArtifactMetadata.newBuilder()
        builder.name = variantName // or artifact name
        builder.applicationId = artifact.applicationId ?: ""
        
        builder.assembleTaskName = artifact.assembleTaskName ?: ""
        builder.compileTaskName = artifact.compileTaskName ?: ""
        builder.sourceGenTaskName = artifact.sourceGenTaskName ?: ""
        builder.resGenTaskName = artifact.resGenTaskName ?: ""
        
        builder.addAllGeneratedSourceFolders(artifact.generatedSourceFolders.map { it.absolutePath })
        builder.addAllGeneratedResourceFolders(artifact.generatedResourceFolders.map { it.absolutePath })
        builder.addAllClassJars(artifact.classesFolders.map { it.absolutePath })
        
        builder.minSdkVersion = artifact.minSdkVersion.apiLevel
        builder.maxSdkVersion = artifact.maxSdkVersion ?: -1
        builder.targetSdkVersionOverride = artifact.targetSdkVersionOverride?.apiLevel ?: -1
        
        builder.signingConfigName = artifact.signingConfigName ?: ""
        builder.isSigned = artifact.isSigned
        
        return builder.build()
    }

    private fun toSourceSetContainer(container: com.android.builder.model.v2.ide.SourceSetContainer): SourceSetContainer {
        val builder = SourceSetContainer.newBuilder()
        container.sourceProvider?.let { builder.sourceProvider = toSourceProvider(it) }
        container.androidTestSourceProvider?.let { builder.androidTestSourceProvider = toSourceProvider(it) }
        container.unitTestSourceProvider?.let { builder.unitTestSourceProvider = toSourceProvider(it) }
        container.testFixturesSourceProvider?.let { builder.testFixturesSourceProvider = toSourceProvider(it) }
        return builder.build()
    }

    private fun toSourceProvider(provider: com.android.builder.model.v2.ide.SourceProvider): SourceProvider {
        val builder = SourceProvider.newBuilder()
        builder.name = provider.name
        builder.manifestFile = provider.manifestFile?.absolutePath ?: ""
        builder.addAllJavaDirectories(provider.javaDirectories.map { it.absolutePath })
        builder.addAllKotlinDirectories(provider.kotlinDirectories.map { it.absolutePath })
        builder.addAllResourcesDirectories(provider.resourcesDirectories.map { it.absolutePath })
        builder.addAllResDirectories(provider.resDirectories?.map { it.absolutePath } ?: emptyList())
        builder.addAllAssetsDirectories(provider.assetsDirectories?.map { it.absolutePath } ?: emptyList())
        builder.addAllAidlDirectories(provider.aidlDirectories?.map { it.absolutePath } ?: emptyList())
        builder.addAllRenderscriptDirectories(provider.renderscriptDirectories?.map { it.absolutePath } ?: emptyList())
        builder.addAllJniLibsDirectories(provider.jniLibsDirectories.map { it.absolutePath })
        builder.addAllShadersDirectories(provider.shadersDirectories?.map { it.absolutePath } ?: emptyList())
        builder.addAllMlModelsDirectories(provider.mlModelsDirectories?.map { it.absolutePath } ?: emptyList())
        
        provider.customDirectories?.forEach { custom ->
             builder.addCustomDirectories(CustomSourceDirectory.newBuilder()
                 .setSourceTypeName(custom.sourceTypeName)
                 .setDirectory(custom.directory.absolutePath)
                 .build())
        }
        return builder.build()
    }

    private fun toAndroidLibrary(key: String, lib: Library): AndroidLibrary {
        val builder = AndroidLibrary.newBuilder()
        builder.key = key
        builder.type = lib.type.name
        builder.artifact = lib.artifact?.absolutePath ?: ""
        
        // Library Info
        lib.libraryInfo?.let { info ->
            builder.group = info.group
            builder.name = info.name
            builder.version = info.version
        }
        
        // Project Info (if it's a module dependency)
        lib.projectInfo?.let { info ->
            builder.projectPath = info.projectPath
        }
        
        // Android Specific Data
        lib.androidLibraryData?.let { data ->
            builder.manifest = data.manifest.absolutePath
            builder.resFolder = data.resFolder.absolutePath
            builder.assetsFolder = data.assetsFolder.absolutePath
            builder.jniFolder = data.jniFolder.absolutePath
            builder.aidlFolder = data.aidlFolder.absolutePath
            builder.renderscriptFolder = data.renderscriptFolder.absolutePath
            builder.proguardRules = data.proguardRules.absolutePath
            builder.lintJar = lib.lintJar?.absolutePath ?: ""
            builder.externalAnnotations = data.externalAnnotations.absolutePath
            builder.publicResources = data.publicResources.absolutePath
            builder.symbolFile = data.symbolFile.absolutePath
            
            builder.addAllCompileJars(data.compileJarFiles.map { it.absolutePath })
            builder.addAllRuntimeJars(data.runtimeJarFiles.map { it.absolutePath })
        }

        return builder.build()
    }
}