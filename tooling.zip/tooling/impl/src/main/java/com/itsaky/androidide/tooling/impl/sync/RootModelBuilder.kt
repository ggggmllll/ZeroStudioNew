/*
 *  This file is part of AndroidIDE.
 *
 *  AndroidIDE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  AndroidIDE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *   along with AndroidIDE.  If not, see <https://www.gnu.org/licenses/>.
 */

package com.itsaky.androidide.tooling.impl.sync

import com.android.builder.model.v2.ide.SyncIssue
import com.itsaky.androidide.builder.model.DefaultSyncIssue
import com.itsaky.androidide.builder.model.shouldBeIgnored
import com.itsaky.androidide.tooling.api.messages.InitializeProjectParams
import com.itsaky.androidide.tooling.api.proto.ProjectModel
import com.itsaky.androidide.tooling.api.proto.ProjectSyncIssues
import com.itsaky.androidide.tooling.api.proto.ProjectType
import com.itsaky.androidide.tooling.impl.Main
import com.itsaky.androidide.tooling.impl.converters.ProtoConverters
import com.itsaky.androidide.tooling.api.util.AndroidModulePropertyCopier
import org.gradle.tooling.ConfigurableLauncher
import org.gradle.tooling.model.idea.IdeaProject
import org.slf4j.LoggerFactory
import java.io.Serializable

/**
 * Utility class to build the project models and return a Protobuf [ProjectModel].
 *
 * @author Akash Yadav
 * @author android_zero
 */
class RootModelBuilder(initializationParams: InitializeProjectParams) :
    AbstractModelBuilder<RootProjectModelBuilderParams, ProjectModel>(initializationParams),
    Serializable {

  private val serialVersionUID = 1L

  override fun build(param: RootProjectModelBuilderParams): ProjectModel {
    val (projectConnection, cancellationToken) = param
    // Capture param to local variable to avoid serialization issues with inner classes
    val initParams = initializationParams 

    val executor =
        projectConnection.action { controller ->
          val ideaProject = controller.getModelAndLog(IdeaProject::class.java)
          val ideaModules = ideaProject.modules

          // Identify Root Module
          val rootModule = ideaModules.find { it.gradleProject.parent == null }
              ?: throw ModelBuilderException("Unable to find root project")

          // Determine if Root is Android
          val rootProjectVersions = getAndroidVersions(rootModule, controller)
          val isAndroidRoot = rootProjectVersions != null

          // Sync Issues Collector
          val syncIssuesList = mutableListOf<DefaultSyncIssue>()
          val syncIssueReporter = ISyncIssueReporter {
            if (it.shouldBeIgnored()) return@ISyncIssueReporter
            val issue = it as? DefaultSyncIssue ?: AndroidModulePropertyCopier.copy(it)
            syncIssuesList.add(issue)
          }

          val modelBuilder = ProjectModel.newBuilder()
          
          // 1. Build Root Project Metadata
          val rootType = if(isAndroidRoot) ProjectType.PROJECT_TYPE_ANDROID else ProjectType.PROJECT_TYPE_GRADLE
          modelBuilder.rootProject = ProtoConverters.toBasicProjectMetadata(rootModule.gradleProject, rootType)

          // 2. Build Sub-projects Metadata
          ideaModules.forEach { module ->
             // Simple heuristic for type
             val versions = getAndroidVersions(module, controller)
             val type = if(versions != null) ProjectType.PROJECT_TYPE_ANDROID else ProjectType.PROJECT_TYPE_JAVA
             modelBuilder.addSubProjects(ProtoConverters.toBasicProjectMetadata(module.gradleProject, type))
          }

          // 3. Build Detailed Model (only for requested module, or root if none requested??)
          // For Initialize, we usually scan all modules. But transferring ALL details via gRPC at once is heavy?
          // No, gRPC can handle it, but it's better to fetch details on demand via GetProjectModel.
          // However, for the "Initialize" response, we might want to return the structure.
          // Current implementation of RootModelBuilder returns the FULL structure.
          
          // Let's implement the logic to populate specific models if this Builder is used recursively.
          // But here, RootModelBuilder is the entry point.
          
          // For gRPC, we will return the "Structure" here. Detailed models for submodules 
          // should be fetched via separate calls if needed, OR we return everything.
          // Since the client expects a full sync initially:
          
          // NOTE: In the legacy implementation, we returned a ProjectImpl containing everything.
          // To keep it simple for now, we will NOT populate 'specific_model' for ALL modules here.
          // The Client can call GetProjectModel(path) later.
          // BUT, we should probably check AGP versions here.
          
          if (rootProjectVersions != null) {
              checkAgpVersion(rootProjectVersions, syncIssueReporter)
          }

          // 4. Sync Issues
          modelBuilder.syncIssues = ProjectSyncIssues.newBuilder()
              .addAllSyncIssues(ProtoConverters.toSyncIssues(
                  com.itsaky.androidide.builder.model.DefaultProjectSyncIssues(syncIssuesList)
              ))
              .build()

          return@action modelBuilder.build()
        }

    Main.finalizeLauncher(executor)
    
    // Inject properties to ensure models are built correctly
    executor.addArguments("-Pandroid.injected.build.model.v2=true")
    executor.addArguments("-Pandroid.injected.invoked.from.ide=true")

    if (cancellationToken != null) {
      executor.withCancellationToken(cancellationToken)
    }

    val logger = LoggerFactory.getLogger("RootModelBuilder")
    logger.info("Starting Gradle Sync...")

    return executor.run().also { 
        logger.info("Gradle Sync finished.") 
    }
  }
}