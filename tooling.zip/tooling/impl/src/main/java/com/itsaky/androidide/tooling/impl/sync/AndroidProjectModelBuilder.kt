/*
 *  This file is part of AndroidIDE.
 *
 *  AndroidIDE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  AndroidIDE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *   along with AndroidIDE.  If not, see <https://www.gnu.org/licenses/>.
 */

package com.itsaky.androidide.tooling.impl.sync

import com.android.builder.model.v2.models.AndroidDsl
import com.android.builder.model.v2.models.AndroidProject
import com.android.builder.model.v2.models.BasicAndroidProject
import com.android.builder.model.v2.models.ModelBuilderParameter
import com.android.builder.model.v2.models.ProjectSyncIssues
import com.android.builder.model.v2.models.VariantDependencies
import com.itsaky.androidide.tooling.api.messages.InitializeProjectParams
import com.itsaky.androidide.tooling.api.proto.ProjectModel
import com.itsaky.androidide.tooling.api.proto.ProjectType
import com.itsaky.androidide.tooling.impl.converters.ProtoConverters

/**
 * Builds model for a single Android application or library project.
 *
 * @author Akash Yadav
 * @author android_zero
 */
class AndroidProjectModelBuilder(initializationParams: InitializeProjectParams) :
    AbstractModelBuilder<AndroidProjectModelBuilderParams, ProjectModel>(initializationParams) {

  override fun build(param: AndroidProjectModelBuilderParams): ProjectModel {
    val (controller, module, versions, syncIssueReporter) = param
    val projectPath = module.gradleProject.path
    
    // 1. Fetch Basic Models
    val basicModel = controller.getModelAndLog(module, BasicAndroidProject::class.java)
    val androidModel = controller.getModelAndLog(module, AndroidProject::class.java)
    val androidDsl = controller.getModelAndLog(module, AndroidDsl::class.java)

    // 2. Select Variant
    val variantNames = basicModel.variants.map { it.name }
    val requestedVariant = initializationParams.androidParams.variantSelections[projectPath]
    val selectedVariant = if (requestedVariant != null && variantNames.contains(requestedVariant)) {
        requestedVariant
    } else {
        variantNames.firstOrNull() ?: "debug"
    }

    log("Selected variant '$selectedVariant' for project '$projectPath'")

    // 3. Fetch Dependencies (Heavy operation)
    val variantDependencies = controller.getModelAndLog(
            module,
            VariantDependencies::class.java,
            ModelBuilderParameter::class.java
        ) {
          it.variantName = selectedVariant
          it.dontBuildRuntimeClasspath = false
          it.dontBuildAndroidTestRuntimeClasspath = true
          it.dontBuildTestFixtureRuntimeClasspath = true
          it.dontBuildUnitTestRuntimeClasspath = true
          it.dontBuildHostTestRuntimeClasspath = emptyMap()
          it.dontBuildScreenshotTestRuntimeClasspath = true
    }

    // 4. Report Issues
    controller.findModel(module, ProjectSyncIssues::class.java)?.also { issues ->
      syncIssueReporter.reportAll(issues)
    }

    // 5. Convert to Proto
    val androidDetail = ProtoConverters.toAndroidProjectDetail(
        basicModel, 
        androidModel, 
        androidDsl, 
        variantDependencies, 
        selectedVariant
    )

    // 6. Wrap in ProjectModel
    return ProjectModel.newBuilder()
        .setBasicInfo(ProtoConverters.toBasicProjectMetadata(module.gradleProject, ProjectType.PROJECT_TYPE_ANDROID))
        .setAndroidModel(androidDetail)
        .build()
  }
}