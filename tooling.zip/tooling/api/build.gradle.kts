/*
 *  This file is part of AndroidIDE.
 *
 *  AndroidIDE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  AndroidIDE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *   along with AndroidIDE.  If not, see <https://www.gnu.org/licenses/>.
 */


@Suppress("JavaPluginLanguageLevel")
plugins {
    id("java-library")
    id("org.jetbrains.kotlin.jvm")
    id("com.google.protobuf")
}

java {
    sourceCompatibility = JavaVersion.VERSION_17
    targetCompatibility = JavaVersion.VERSION_17
}

dependencies {
  implementation(libs.google.protobuf.kotlin)
  implementation(libs.grpc.protobuf)
  implementation(libs.grpc.stub)
  implementation(libs.grpc.kotlin.stub)
  compileOnly(libs.common.javax.annotation.api)
   
  api(projects.logging.logger)
  api(projects.tooling.events)
  api(projects.tooling.model)
  api(projects.tooling.builderModelImpl)
  api(projects.xml.dom)
  api(projects.utilities.buildInfo)
  api(projects.utilities.shared)
  implementation(projects.logging.logger)
  
  api(libs.google.gson)
    
  implementation(libs.common.jkotlin)
  
}


protobuf {
    protoc {
        artifact = "com.google.protobuf:protoc:4.33.2"
    }
    plugins {
        // 注册 Java gRPC 生成器
        create("grpc") {
            artifact = "io.grpc:protoc-gen-grpc-java:1.78.0"
        }
        // 注册 Kotlin gRPC 生成器 (用于协程支持)
        create("grpckt") {
            artifact = "io.grpc:protoc-gen-grpc-kotlin:1.5.0:jdk8@jar"
        }
    }
    generateProtoTasks {
        all().forEach { task ->
            task.plugins {
                create("grpc") { 
                    option("lite") // 使用 lite 模式减小体积
                }
                create("grpckt") {
                    option("lite")
                }
            }
            task.builtins {
                getByName("java") { 
                    option("lite") // Java Lite 模式
                }
                create("kotlin") {
                    option("lite")
                }
            }
        }
    }
}