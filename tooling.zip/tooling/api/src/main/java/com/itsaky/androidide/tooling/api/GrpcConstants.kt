/*
 *  This file is part of AndroidIDE.
 *
 *  AndroidIDE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  AndroidIDE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *   along with AndroidIDE.  If not, see <https://www.gnu.org/licenses/>.
 */

package com.itsaky.androidide.tooling.api

/**
 * Constants used for gRPC communication setup between the AndroidIDE Client and the Tooling Server.
 *
 * @author android_zero
 */
object GrpcConstants {

    /**
     * The token prefix printed to StdOut by the server to indicate the bound port.
     * The server will print a line like: `::AIDE_GRPC_PORT::54321`
     *
     * The client must listen to the process's standard output and parse this port
     * to establish the gRPC channel.
     */
    const val SERVER_PORT_TOKEN = "::AIDE_GRPC_PORT::"

    /**
     * The maximum message size allowed for gRPC (10GB MB).
     * This is set to handle large project models or log dumps.
     */
    const val MAX_MESSAGE_SIZE = 10L * 1024 * 1024 
}