/*
 *  This file is part of AndroidIDE.
 *
 *  AndroidIDE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  AndroidIDE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *   along with AndroidIDE.  If not, see <https://www.gnu.org/licenses/>.
 */

package com.itsaky.androidide.tooling.api

import com.itsaky.androidide.tooling.api.proto.ProjectType
import java.util.concurrent.CompletableFuture

/**
 * Interface for querying project details.
 * Refactored to use Protobuf models.
 *
 * @author Akash Yadav
 * @author android_zero
 */
interface IProjectQueries {

  /**
   * Select the project to work with.
   *
   * @param projectPath The project's path. If empty, the root project is selected.
   * @return A future returning true if selection was successful.
   */
  fun selectProject(projectPath: String): CompletableFuture<Boolean>

  /** Get the type of selected project. */
  fun getType(): CompletableFuture<ProjectType>

  /** Get the selected project as Gradle project. */
  fun asGradleProject(): IGradleProject

  /** Get the selected project as Android project. */
  fun asAndroidProject(): IAndroidProject

  /** Get the selected project as Java project. */
  fun asJavaProject(): IJavaProject
}