package android.zero.studio.treeview.adapter;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import android.zero.studio.treeview.model.TreeNode;
import android.zero.studio.treeview.view.AndroidTreeView;

import java.util.ArrayList;
import java.util.List;

public class TreeAdapter extends RecyclerView.Adapter<TreeAdapter.RvViewHolder> {

    private final Context context;
    private TreeNode root;
    private final List<TreeNode> displayNodes; // 扁平化后的可见节点列表
    private final int indentation; // 缩进像素值
    private final AndroidTreeView treeView;

    // 默认 ViewHolder 实例缓存，用于 createNodeView
    private TreeNode.BaseNodeViewHolder defaultHolder;

    public TreeAdapter(Context context, TreeNode root, int indentation, AndroidTreeView treeView) {
        this.context = context;
        this.root = root;
        this.indentation = indentation;
        this.treeView = treeView;
        this.displayNodes = new ArrayList<>();
        
        // 初始化：将 Root 展开并填充列表 (不包含 Root 本身，只包含子节点，模拟原版行为)
        // 如果想包含 Root，可以调整这里
        buildVisibleList(root, displayNodes);
    }

    /**
     * 核心逻辑：递归构建当前可见的节点列表
     */
    private void buildVisibleList(TreeNode parent, List<TreeNode> list) {
        if (parent.isExpanded()) {
            for (TreeNode child : parent.getChildren()) {
                list.add(child);
                if (child.isExpanded()) {
                    buildVisibleList(child, list);
                }
            }
        }
    }

    @NonNull
    @Override
    public RvViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // 这里为了简单，假设所有节点使用相同的 ViewHolder 布局逻辑
        // 如果需要多类型，可以在 getItemViewType 中根据 Node 返回 type
        // 实际上 createNodeView 是由用户定义的 BaseNodeViewHolder 实现的
        
        // 这是一个极其 tricky 的地方：我们需要一个 BaseNodeViewHolder 的实例来调用 createNodeView
        // 实际项目中，建议用户通过 Factory 模式提供 View，这里为了兼容旧逻辑做了适配
        if (defaultHolder == null) {
             // 这一步在实际运行时需要从某处获取，这里假设 AndroidTreeView 传进来了
             // 简化处理：我们创建一个空的 FrameLayout 作为容器
             FrameLayout container = new FrameLayout(context);
             container.setLayoutParams(new RecyclerView.LayoutParams(
                     ViewGroup.LayoutParams.MATCH_PARENT, 
                     ViewGroup.LayoutParams.WRAP_CONTENT));
             return new RvViewHolder(container);
        }
        return null; // Should not happen if logic is correct below
    }
    
    // 覆盖这个方法，让每个节点负责创建自己的 View
    @NonNull
    @Override
    public RvViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // 此时我们无法获取具体的 Node，所以这是一个限制。
        // 为了完美实现，我们在 onBindViewHolder 里动态 addView (虽然性能稍差但兼容性好)
        // 或者，更好的方式：创建一个通用的 Container
        FrameLayout container = new FrameLayout(context);
        container.setLayoutParams(new RecyclerView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        return new RvViewHolder(container);
    }

    @Override
    public void onBindViewHolder(@NonNull RvViewHolder holder, int position) {
        TreeNode node = displayNodes.get(position);
        
        // 1. 处理缩进 (通过 Padding 实现，高效)
        int paddingLeft = (node.getLevel() - 1) * indentation; // Root level is 0, first child is 1
        if (paddingLeft < 0) paddingLeft = 0;
        holder.itemView.setPadding(paddingLeft, 0, 0, 0);

        // 2. 渲染内容
        // 这里需要反射或工厂来获取用户的 ViewHolder
        // 极度优化：如果容器里已经有 View 且类型匹配，则复用，否则清除重建
        FrameLayout container = (FrameLayout) holder.itemView;
        
        TreeNode.BaseNodeViewHolder<?> userHolder = getUserViewHolderInstance(node);
        
        if (container.getChildCount() > 0) {
            View child = container.getChildAt(0);
            Object tag = child.getTag();
            // 如果 View 的类型和当前 Node 需要的类型不一致，移除重建
            if (tag == null || !tag.equals(node.getViewHolderClass())) {
                container.removeAllViews();
                View view = userHolder.createNodeView(container, 0);
                view.setTag(node.getViewHolderClass());
                container.addView(view);
            }
        } else {
            View view = userHolder.createNodeView(container, 0);
            view.setTag(node.getViewHolderClass());
            container.addView(view);
        }

        // 3. 绑定数据
        // 获取容器内的 View
        View contentView = container.getChildAt(0);
        userHolder.bindView(node, node.getValue(), contentView);
        userHolder.toggle(node.isExpanded());
        
        // 4. 处理点击事件 (展开/折叠 + 历史记录)
        contentView.setOnClickListener(v -> {
            treeView.toggleNode(node); // 核心逻辑委托给 TreeView
        });
        
        contentView.setOnLongClickListener(v -> {
            // 长按逻辑
            return true;
        });
    }

    private TreeNode.BaseNodeViewHolder getUserViewHolderInstance(TreeNode node) {
        // 这里使用反射简单实例化，生产环境建议使用缓存或享元模式优化
        try {
            TreeNode.BaseNodeViewHolder holder = node.getViewHolderClass().getConstructor(Context.class).newInstance(context);
            return holder;
        } catch (Exception e) {
            throw new RuntimeException("Failed to instantiate ViewHolder", e);
        }
    }

    @Override
    public int getItemCount() {
        return displayNodes.size();
    }

    // ---------------- 操作逻辑 ----------------

    /**
     * 展开节点
     */
    public void expandNode(TreeNode node) {
        int position = displayNodes.indexOf(node);
        if (position >= 0 && !node.isExpanded()) {
            node.setExpanded(true);
            
            // 获取所有需要插入的子节点（包含子节点的子节点...）
            List<TreeNode> childrenToAdd = new ArrayList<>();
            buildVisibleList(node, childrenToAdd); // 这里 buildVisibleList 会递归找
            
            // 如果 node 是之前是 collapse 的，buildVisibleList 里的递归条件是 if(parent.isExpanded())
            // 因为我们刚刚 setExpanded(true)，所以现在可以获取它的直接子节点
            // 但是直接子节点的子节点是否添加，取决于直接子节点的 expanded 状态
            
            // 修正逻辑：因为刚设为true，buildVisibleList只会添加直接子节点(如果直接子节点原本是collapsed)
            // 重新实现一个简单的：获取应该显示的子树
            childrenToAdd.clear();
            addDescendants(node, childrenToAdd);

            if (!childrenToAdd.isEmpty()) {
                displayNodes.addAll(position + 1, childrenToAdd);
                notifyItemRangeInserted(position + 1, childrenToAdd.size());
                notifyItemChanged(position); // 刷新当前节点图标（展开状态）
            }
        }
    }
    
    private void addDescendants(TreeNode parent, List<TreeNode> list) {
        if (parent.isExpanded()) {
            for (TreeNode child : parent.getChildren()) {
                list.add(child);
                addDescendants(child, list);
            }
        }
    }

    /**
     * 折叠节点
     */
    public void collapseNode(TreeNode node) {
        int position = displayNodes.indexOf(node);
        if (position >= 0 && node.isExpanded()) {
            node.setExpanded(false);
            
            // 计算需要移除多少个节点
            int count = 0;
            // 从当前节点下一个开始检查
            for (int i = position + 1; i < displayNodes.size(); i++) {
                TreeNode nextNode = displayNodes.get(i);
                // 如果下一个节点的层级比当前节点深，说明它是当前节点的子孙
                if (nextNode.getLevel() > node.getLevel()) {
                    count++;
                } else {
                    break; // 遇到了同级或上级节点，停止
                }
            }

            if (count > 0) {
                // 必须倒序删除或者使用 subList clear
                displayNodes.subList(position + 1, position + 1 + count).clear();
                notifyItemRangeRemoved(position + 1, count);
            }
            notifyItemChanged(position); // 刷新当前节点图标
        }
    }
    
    /**
     * 更新全部数据
     */
    public void refreshAll() {
        displayNodes.clear();
        buildVisibleList(root, displayNodes);
        notifyDataSetChanged();
    }

    static class RvViewHolder extends RecyclerView.ViewHolder {
        public RvViewHolder(@NonNull View itemView) {
            super(itemView);
        }
    }
}