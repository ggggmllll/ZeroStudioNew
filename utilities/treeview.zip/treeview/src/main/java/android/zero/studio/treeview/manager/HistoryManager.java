package android.zero.studio.treeview.manager;

import android.zero.studio.treeview.model.TreeNode;
import java.util.ArrayList;
import java.util.List;

/**
 * 高性能历史记录管理器 (指针栈模式)
 * 负责记录节点的 展开/折叠 操作，支持 Undo/Redo。
 * @author android_zero
 */
public class HistoryManager {

    public enum ActionType {
        EXPAND,
        COLLAPSE
    }

    public static class HistoryAction {
        public final TreeNode node;
        public final ActionType type; // 记录的是"执行了什么操作"

        public HistoryAction(TreeNode node, ActionType type) {
            this.node = node;
            this.type = type;
        }
    }

    // 使用 ArrayList 作为栈存储，配合指针，避免频繁的对象创建和链表开销
    private final List<HistoryAction> historyStack;
    private int pointer; // 指向当前状态的指针，-1 表示初始状态
    private final int maxHistorySize;

    public HistoryManager(int maxSize) {
        this.historyStack = new ArrayList<>(maxSize);
        this.maxHistorySize = maxSize;
        this.pointer = -1;
    }

    /**
     * 记录一次操作
     */
    public void push(TreeNode node, ActionType type) {
        // 如果指针不在栈顶，说明进行过 Undo，此时新的操作需要清除指针之后的所有记录（重写历史）
        if (pointer < historyStack.size() - 1) {
            // 高效清除：subList clear
            historyStack.subList(pointer + 1, historyStack.size()).clear();
        }

        // 限制栈大小，防止无限增长
        if (historyStack.size() >= maxHistorySize) {
            historyStack.remove(0); // 移除最旧的
            pointer--; // 调整指针
        }

        historyStack.add(new HistoryAction(node, type));
        pointer++;
    }

    /**
     * 撤销上一次操作
     * @return 撤销动作的逆向操作信息，如果无法撤销返回 null
     */
    public HistoryAction undo() {
        if (pointer < 0) return null;

        HistoryAction lastAction = historyStack.get(pointer);
        pointer--;
        
        // 撤销意味着执行反向操作：如果记录的是 EXPAND，撤销就是 COLLAPSE
        ActionType inverseType = (lastAction.type == ActionType.EXPAND) ? ActionType.COLLAPSE : ActionType.EXPAND;
        return new HistoryAction(lastAction.node, inverseType);
    }

    /**
     * 重做被撤销的操作
     * @return 重做动作的信息，如果无法重做返回 null
     */
    public HistoryAction redo() {
        if (pointer >= historyStack.size() - 1) return null;

        pointer++;
        HistoryAction nextAction = historyStack.get(pointer);
        
        // 重做就是再次执行当初记录的操作
        return nextAction;
    }

    public boolean canUndo() {
        return pointer >= 0;
    }

    public boolean canRedo() {
        return pointer < historyStack.size() - 1;
    }
    
    public void clear() {
        historyStack.clear();
        pointer = -1;
    }
}