package android.zero.studio.treeview.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * 纯数据节点模型，移除所有 View 引用以防止内存泄漏。
 * Modified for RecyclerView by android_zero
 */
public class TreeNode {
    public static final String NODES_ID_SEPARATOR = ":";

    private int mId;
    private static int mLastId = 0;
    
    private TreeNode mParent;
    private final List<TreeNode> children = new ArrayList<>();
    private Object mValue;
    
    // 状态位
    private boolean mExpanded = false;
    private boolean mSelected = false;
    private boolean mSelectable = true;
    
    // 缓存层级，避免递归计算
    private int mLevel = -1;
    
    // 绑定 ViewHolder 的 Class，用于 RecyclerView 创建 View
    private Class<? extends BaseNodeViewHolder> mViewHolderClass;

    public TreeNode(Object value) {
        this.mValue = value;
        this.mId = generateId();
    }

    public static TreeNode root() {
        TreeNode root = new TreeNode(null);
        root.setSelectable(false);
        return root;
    }

    private int generateId() {
        return ++mLastId;
    }

    public TreeNode addChild(TreeNode childNode) {
        childNode.mParent = this;
        childNode.mLevel = -1; // 重置层级缓存
        children.add(childNode);
        return this;
    }

    public List<TreeNode> getChildren() {
        return children;
    }

    public TreeNode getParent() {
        return mParent;
    }

    public boolean isLeaf() {
        return children.isEmpty();
    }

    public Object getValue() {
        return mValue;
    }

    public boolean isExpanded() {
        return mExpanded;
    }

    public void setExpanded(boolean expanded) {
        mExpanded = expanded;
    }

    public void setSelected(boolean selected) {
        mSelected = selected;
    }

    public boolean isSelected() {
        return mSelectable && mSelected;
    }

    public void setSelectable(boolean selectable) {
        mSelectable = selectable;
    }

    public int getLevel() {
        if (mLevel != -1) return mLevel;
        int level = 0;
        TreeNode root = this;
        while (root.mParent != null) {
            root = root.mParent;
            level++;
        }
        mLevel = level;
        return mLevel;
    }

    public void setViewHolderClass(Class<? extends BaseNodeViewHolder> viewHolderClass) {
        this.mViewHolderClass = viewHolderClass;
    }

    public Class<? extends BaseNodeViewHolder> getViewHolderClass() {
        return mViewHolderClass;
    }

    /**
     * 抽象 ViewHolder，用户需要继承此类来实现 UI。
     * 现在它不再持有 View，而是作为 RecyclerView Adapter 的委托。
     */
    public abstract static class BaseNodeViewHolder<E> {
        protected TreeNode mNode;
        
        // 用于切换高亮、选中状态
        public abstract void toggle(boolean active);
        public void toggleSelectionMode(boolean editModeEnabled) {}
        public void toggleHighlight(boolean highlighted) {}
        
        // 绑定数据到 View (相当于 RecyclerView 的 onBindViewHolder)
        public abstract void bindView(TreeNode node, E value, android.view.View view);
        
        // 创建 View (相当于 RecyclerView 的 onCreateViewHolder)
        public abstract android.view.View createNodeView(android.view.ViewGroup parent, int viewType);
    }
}