package android.zero.studio.treeview.holder;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.zero.studio.treeview.model.TreeNode;

public class SimpleViewHolder extends TreeNode.BaseNodeViewHolder<Object> {

    private TextView textView;
    private final Context context;

    public SimpleViewHolder(Context context) {
        this.context = context;
    }

    @Override
    public View createNodeView(ViewGroup parent, int viewType) {
        textView = new TextView(context);
        textView.setPadding(20, 20, 20, 20); // 内部 Padding
        return textView;
    }

    @Override
    public void bindView(TreeNode node, Object value, View view) {
        TextView tv = (TextView) view;
        tv.setText(String.valueOf(value));
        
        // 样式处理
        if (node.isSelected()) {
            tv.setBackgroundColor(0xFFDDDDDD); // 灰色选中
        } else {
            tv.setBackgroundColor(0xFFFFFFFF); // 白色背景
        }
        
        // 展开/折叠 指示器 (简单文本模拟)
        if (!node.isLeaf()) {
            tv.setText((node.isExpanded() ? "[-] " : "[+] ") + value.toString());
        }
    }

    @Override
    public void toggle(boolean active) {
        // 在 bindView 中已经处理了，如果需要动画可以在这里做
    }
}