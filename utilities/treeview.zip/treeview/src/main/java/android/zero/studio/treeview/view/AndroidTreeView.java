package android.zero.studio.treeview.view;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.SimpleItemAnimator;

import android.zero.studio.treeview.adapter.TreeAdapter;
import android.zero.studio.treeview.manager.HistoryManager;
import android.zero.studio.treeview.model.TreeNode;

/**
 * 极致性能 TreeView (基于 RecyclerView)
 * Created by android_zero
 */
public class AndroidTreeView {

    private final Context mContext;
    private TreeNode mRoot;
    private RecyclerView mRecyclerView;
    private TreeAdapter mAdapter;
    private final HistoryManager mHistoryManager;
    private boolean mUseHistory = true; // 开关

    public AndroidTreeView(Context context, TreeNode root) {
        this.mContext = context;
        this.mRoot = root;
        // 初始化历史记录栈，容量 100
        this.mHistoryManager = new HistoryManager(100);
    }

    /**
     * 获取构建好的 View
     */
    public View getView() {
        if (mRecyclerView == null) {
            mRecyclerView = new RecyclerView(mContext);
            mRecyclerView.setLayoutParams(new ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, 
                    ViewGroup.LayoutParams.MATCH_PARENT));
            
            // 核心：线性布局管理器
            mRecyclerView.setLayoutManager(new LinearLayoutManager(mContext));
            
            // 优化：关闭默认动画以防止闪烁，或者使用默认动画增加体验
            // ((SimpleItemAnimator) mRecyclerView.getItemAnimator()).setSupportsChangeAnimations(false);
            
            // 缩进距离：20dp 转 px
            int indentation = (int) (20 * mContext.getResources().getDisplayMetrics().density);
            
            mAdapter = new TreeAdapter(mContext, mRoot, indentation, this);
            mRecyclerView.setAdapter(mAdapter);
        }
        return mRecyclerView;
    }

    /**
     * 切换节点状态 (API 供 Adapter 调用)
     */
    public void toggleNode(TreeNode node) {
        if (node.isExpanded()) {
            collapseNode(node, true); // true 表示记录历史
        } else {
            expandNode(node, true);
        }
    }

    public void expandNode(TreeNode node, boolean recordHistory) {
        if (node.isExpanded()) return;
        
        // 记录历史
        if (recordHistory && mUseHistory) {
            mHistoryManager.push(node, HistoryManager.ActionType.EXPAND);
        }
        
        // 执行 Adapter 更新
        mAdapter.expandNode(node);
    }

    public void collapseNode(TreeNode node, boolean recordHistory) {
        if (!node.isExpanded()) return;

        // 记录历史
        if (recordHistory && mUseHistory) {
            mHistoryManager.push(node, HistoryManager.ActionType.COLLAPSE);
        }

        // 执行 Adapter 更新
        mAdapter.collapseNode(node);
    }

    // --- 历史记录操作 ---

    public void undo() {
        if (!mHistoryManager.canUndo()) return;

        HistoryManager.HistoryAction action = mHistoryManager.undo();
        if (action == null) return;

        // 执行反向操作，但不记录历史（避免死循环）
        if (action.type == HistoryManager.ActionType.EXPAND) {
            expandNode(action.node, false);
        } else {
            collapseNode(action.node, false);
        }
    }

    public void redo() {
        if (!mHistoryManager.canRedo()) return;

        HistoryManager.HistoryAction action = mHistoryManager.redo();
        if (action == null) return;

        // 执行重做操作，但不记录历史
        if (action.type == HistoryManager.ActionType.EXPAND) {
            expandNode(action.node, false);
        } else {
            collapseNode(action.node, false);
        }
    }
    
    public void clearHistory() {
        mHistoryManager.clear();
    }

    // --- 其他 API ---

    public void setUseHistory(boolean use) {
        this.mUseHistory = use;
    }
    
    public void setRoot(TreeNode root) {
        this.mRoot = root;
        // 重置 Adapter
        if (mAdapter != null) {
            mAdapter = new TreeAdapter(mContext, mRoot, 50, this);
            mRecyclerView.setAdapter(mAdapter);
        }
    }
}