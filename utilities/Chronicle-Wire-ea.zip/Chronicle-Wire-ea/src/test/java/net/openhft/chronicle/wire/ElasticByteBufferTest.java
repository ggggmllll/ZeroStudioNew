/*
 * Copyright 2013-2025 chronicle.software; SPDX-License-Identifier: Apache-2.0
 */
package net.openhft.chronicle.wire;

import net.openhft.chronicle.bytes.Bytes;
import net.openhft.chronicle.core.Jvm;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.junit.Assert;
import org.junit.Test;

import java.nio.ByteBuffer;

import static org.junit.Assume.assumeFalse;

// Test class focusing on the functionality of elastic byte buffers with wire operations.
public class ElasticByteBufferTest extends WireTestCommon {

    @Test
    public void testElasticByteBufferWithWire() {
        assumeFalse(Jvm.maxDirectMemory() == 0);

        // Initialize an elastic byte buffer with initial size of 10.
        Bytes<ByteBuffer> byteBufferBytes = Bytes.elasticByteBuffer(10);

        // Use binary wire type with padding enabled.
        Wire wire = WireType.BINARY.apply(byteBufferBytes);
        wire.usePadding(true);

        // Write a key-value pair into the wire document.
        try (DocumentContext documentContext = wire.writingDocument(false)) {
            documentContext.wire().write("some key").text("some value of more than ten characters");
        }

        @Nullable ByteBuffer byteBuffer = byteBufferBytes.underlyingObject();
        StringBuilder stringBuilder = new StringBuilder();
        while (byteBuffer.remaining() > 0) {
            stringBuilder.append((char) byteBuffer.get());
        }

        // Assert that the text was written correctly.
        @NotNull String s = stringBuilder.toString();
        Assert.assertTrue(s.contains("some value of more than ten characters"));

        byteBufferBytes.releaseLast();
    }
}
