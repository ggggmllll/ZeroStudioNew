/*
 * Copyright 2013-2025 chronicle.software; SPDX-License-Identifier: Apache-2.0
 */
package net.openhft.chronicle.wire;

import net.openhft.chronicle.bytes.MethodReader;
import net.openhft.chronicle.core.annotation.UsedViaReflection;

/**
 * Records the path a message takes as it moves through components.
 * Each processing step may append its source identifier and timestamp,
 * allowing tracing and latency analysis in distributed systems.
 */
public interface MessageHistory extends Marshallable {

    /**
     * Retrieves the thread-local {@code MessageHistory} instance for the
     * message being processed.
     *
     * @return the history associated with the current excerpt.
     */
    static MessageHistory get() {
        return VanillaMessageHistory.getThreadLocal();
    }

    /**
     * You only need to call this if you wish to override its behaviour.
     *
     * @param md to change to the default implementation for this thread. Null to clear the thread local
     *           and force withInitial to be called again
     */
    static void set(MessageHistory md) {
        VanillaMessageHistory.setThreadLocal(md);
    }

    /**
     * Effectively calls {@code set(null)} removing the current thread-local
     * history.
     */
    static void clear() {
        VanillaMessageHistory.setThreadLocal(null);
    }

    /**
     * Sets the current thread-local history to a new empty
     * {@link VanillaMessageHistory}.
     */
    static void emptyHistory() {
        VanillaMessageHistory.setThreadLocal(new VanillaMessageHistory());
    }

    /**
     * Writes the current thread's history to the given document if the
     * document is empty.
     *
     * @param dc the {@link DocumentContext} to write the history to
     */
    @UsedViaReflection
    static void writeHistory(DocumentContext dc) {
        if (((WriteDocumentContext) dc).isEmpty()) { // only add to the start of a message. i.e. for chained calls.
            get().doWriteHistory(dc);
        }
    }

    // needed by NoMessageHistory in Queue
    /**
     * Default implementation for recording history into the supplied
     * {@link DocumentContext}. It writes an event named
     * {@link net.openhft.chronicle.bytes.MethodReader#HISTORY} with this history
     * as the value.
     *
     * @param dc the document to append the history to
     */
    default void doWriteHistory(DocumentContext dc) {
        dc.wire().writeEventName(MethodReader.HISTORY).marshallable(get());
    }

    /**
     * Returns the number of timings contained in this {@code MessageHistory}.
     *
     * @return the number of timings contained in this {@code MessageHistory}.
     */
    int timings();

    /**
     * Returns a timing at a position specified by the input {@code n}.
     *
     * @return a timing at a position specified by the input {@code n}.
     */
    long timing(int n);

    /**
     * Returns the number of sources contained in this {@code MessageHistory}.
     *
     * @return the number of sources contained in this {@code MessageHistory}.
     */
    int sources();

    /**
     * Returns the source id at a position specified by the input {@code n}.
     *
     * @return the source id at a position specified by the input {@code n}.
     */
    int sourceId(int n);

    /**
     * Returns {@code true} if the source ids contained in this
     * {@code MessageHistory} end with the provided {@code sourceIds}.
     *
     * @return {@code true} if the source ids contained in this
     * {@code MessageHistory} end with the provided {@code sourceIds}.
     */
    boolean sourceIdsEndsWith(int[] sourceIds);

    /**
     * Returns the index of the source at a position specified by the
     * input {@code n}.
     *
     * @return the index of the source at a position specified by the
     * input {@code n}.
     */
    long sourceIndex(int n);

    /**
     * Clears all recorded source and timing entries.
     */
    @Override
    void reset();

    /**
     * Resets the {@code MessageHistory} with the provided {@code sourceId}
     * and {@code sourceIndex} as a starting point.
     */
    void reset(int sourceId, long sourceIndex);

    /**
     * Returns the last source id contained in this {@code MessageHistory}.
     *
     * @return the last source id contained in this {@code MessageHistory}.
     */
    int lastSourceId();

    /**
     * Returns the last source index contained in this {@code MessageHistory}.
     *
     * @return the last source index contained in this {@code MessageHistory}.
     */
    long lastSourceIndex();

    /**
     * @return {@code true} if the message history has not been written using
     * {@link Marshallable#writeMarshallable(net.openhft.chronicle.wire.WireOut)}
     */
    boolean isDirty();
}
