/*
 * Copyright 2013-2025 chronicle.software; SPDX-License-Identifier: Apache-2.0
 */
package net.openhft.chronicle.wire;

import net.openhft.chronicle.bytes.MethodReader;
import net.openhft.chronicle.bytes.MethodWriterInvocationHandler;
import net.openhft.chronicle.core.io.InvalidMarshallableException;
import net.openhft.chronicle.core.util.AbstractInvocationHandler;
import org.jetbrains.annotations.NotNull;

import java.lang.reflect.Method;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * An abstract base for {@link MethodWriterInvocationHandler}s that provides a base implementation.
 * It manages the invocation by mapping methods to their respective parameter holders and writing them to wires.
 * This class can handle both regular and generic events and supports method IDs for binary output.
 */
public abstract class AbstractMethodWriterInvocationHandler extends AbstractInvocationHandler implements MethodWriterInvocationHandler {

    // Cache of analysed parameter writers keyed by method
    private final Map<Method, ParameterHolderSequenceWriter> parameterMap = new ConcurrentHashMap<>();

    // If true a {@link MessageHistory} is written before each event
    protected boolean recordHistory;

    /**
     * Name of the method used for generic events. The first argument becomes
     * the event name on the wire.
     */
    protected String genericEvent = "";

    // Use numeric {@link MethodId} values when writing to binary wires
    private boolean useMethodIds;

    /**
     * Constructor accepting the type of class the handler operates on.
     *
     * @param tClass The class type this handler is designed for.
     */
    protected AbstractMethodWriterInvocationHandler(Class<?> tClass) {
        super(tClass);
    }

    @Override
    protected Object doInvoke(Object proxy, Method method, Object[] args) {
        handleInvoke(method, args);

        return method.getReturnType().isInterface() ? proxy : null;
    }

    @Override
    public void genericEvent(String genericEvent) {
        this.genericEvent = genericEvent;
    }

    /**
     * Abstract method to handle a method invocation with its respective arguments.
     *
     * @param method The method being invoked.
     * @param args   Arguments provided for the method invocation.
     */
    protected abstract void handleInvoke(Method method, Object[] args);

    /**
     * Handles the method invocation, writes the event details to the provided wire,
     * and supports optional recording of method history.
     *
     * @param method The method being invoked.
     * @param args   Arguments provided for the method invocation.
     * @param wire   The wire output to write the event details.
     * @throws InvalidMarshallableException If there's an error during marshalling.
     */
    protected void handleInvoke(@NotNull Method method, Object[] args, Wire wire) throws InvalidMarshallableException {
        if (recordHistory) {
            wire.writeEventName(MethodReader.HISTORY)
                    .marshallable(MessageHistory.get());
        }
        String methodName = method.getName();

        // Distinguish between a generic event and a regular one
        if (methodName.equals(genericEvent)) {
            writeGenericEvent(wire, method, args);
            return;
        }
        writeEvent(wire, method, methodName, args);
    }

    // Helper to write a regular event to the wire
    private void writeEvent(Wire wire, @NotNull Method method, String methodName, Object[] args) throws InvalidMarshallableException {
        writeEvent0(wire, method, args, methodName, 0);
    }

    // Helper to write a generic event where the first argument supplies the event name
    private void writeGenericEvent(Wire wire, @NotNull Method method, Object[] args) throws InvalidMarshallableException {
        String methodName = args[0].toString();
        writeEvent0(wire, method, args, methodName, 1);
    }

    /**
     * Writes the event name or ID followed by the parameters, distinguishing between methods with and without arguments
     *
     * @param wire      target wire
     * @param method    source method
     * @param args      arguments array
     * @param methodName resolved name to write
     * @param oneParam   index offset when the first argument is the event name
     */
    @SuppressWarnings("unchecked")
    private void writeEvent0(Wire wire, @NotNull Method method, Object[] args, String methodName, int oneParam) throws InvalidMarshallableException {
        // Fetch or compute the parameter holder for the method
        final ParameterHolderSequenceWriter phsw = parameterMap.computeIfAbsent(method, ParameterHolderSequenceWriter::new);
        boolean useMethodId = useMethodIds && phsw.methodId >= 0 && wire.getValueOut().isBinary();
        ValueOut valueOut = useMethodId
                ? wire.writeEventId((int) phsw.methodId)
                : wire.writeEventName(methodName);

        // Write to the wire based on argument count
        switch (args.length - oneParam) {
            case 0:
                valueOut.text("");
                break;
            case 1:
                Object arg = args[oneParam];
                if (arg != null && arg.getClass() == RawText.class)
                    valueOut.rawText(((RawText) arg).text);
                else
                    valueOut.object(phsw.parameterTypes[oneParam], arg);
                break;
            default:
                valueOut.sequence(args, oneParam == 0 ? phsw.from0 : phsw.from1);
        }
    }

    @Override
    public void recordHistory(boolean recordHistory) {
        this.recordHistory = recordHistory;
    }

    @Override
    public void useMethodIds(boolean useMethodIds) {
        this.useMethodIds = useMethodIds;
    }
}
