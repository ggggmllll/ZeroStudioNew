/*
 * Copyright 2013-2025 chronicle.software; SPDX-License-Identifier: Apache-2.0
 */
package net.openhft.chronicle.wire.converter;

import net.openhft.chronicle.wire.LongConversion;
import net.openhft.chronicle.wire.LongConverter;
import net.openhft.chronicle.wire.ShortTextLongConverter;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Annotation to indicate that a given field or parameter, represented as a long value,
 * should be treated as a string containing 0 to 10 characters in Base85 format. This truncated leading spaces, but preserves leading zero c.f. {@link Base85}
 * <p>
 * Base85, also known as Ascii85, is a binary-to-ASCII encoding scheme that provides
 * an efficient way to encode binary data for transport over text-based protocols.
 * <p>
 * When this annotation is applied to a field or parameter, it provides a hint about the expected format
 * and representation of the data, allowing for potential encoding and decoding operations based on Base85.
 * <p>
 * The provided {@link #INSTANCE} is a default converter that can be used for operations relevant to the Base85 format.
 * <b>Usage Example:</b>
 * <pre>
 * {@code @ShortText}
 * private long encodedText;
 * </pre>
 *
 * @see LongConverter
 * @see Base85
 * @see ShortTextLongConverter
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.FIELD, ElementType.PARAMETER})
@LongConversion(ShortText.class)
public @interface ShortText {

    /**
     * An instance of {@link ShortTextLongConverter} specifically configured for Base85 conversions.
     * This converter uses a character set defined by the {@link ShortTextLongConverter} to represent Base85 encoded data.
     */
    LongConverter INSTANCE = ShortTextLongConverter.INSTANCE;
}
